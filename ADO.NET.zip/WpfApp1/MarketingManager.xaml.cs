﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    public partial class MarketingManager : Page
    {
        private storeAutoEntities entities = new storeAutoEntities();

        public MarketingManager()
        {
            InitializeComponent();

            InitializeDataGrids();
        }

        private void InitializeDataGrids()
        {
           
            gridManufacturers.ItemsSource = entities.Manufacturers.ToList();
         
            gridManufacturerContracts.ItemsSource = entities.ManufacturerContracts.ToList();


            
            gridManufacturers.SelectionChanged += DataGrid_SelectionChanged;
            
            gridManufacturerContracts.SelectionChanged += DataGrid_SelectionChanged;
            this.MouseDown += Page_MouseDown;

        }


        private void Page_MouseDown(object sender, MouseButtonEventArgs e)
        {

            ClearInputFields();
        }

        private void ClearInputFields()
        {

            
            txtManufacturerID.Text = string.Empty;
            dpStartDate2.SelectedDate = null;
            dpEndDate2.SelectedDate = null;
            txtTerms.Text = string.Empty;
          
           
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {

            MainWindow mainWindow = new MainWindow();

            Application.Current.MainWindow = mainWindow;

            NavigationService?.Navigate(null);
        }



        private void AddManufacturer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtManufacturerName.Text))
                {
                    MessageBox.Show("Введите имя марки.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtCountry.Text))
                {
                    MessageBox.Show("Введите страну.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtWebsite.Text))
                {
                    MessageBox.Show("Введите сайт");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtManufacturerName.Text) || string.IsNullOrWhiteSpace(txtCountry.Text) || string.IsNullOrWhiteSpace(txtWebsite.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }


                var newManufacturer = new Manufacturers
                {
                    Name = txtManufacturerName.Text,
                    Country = txtCountry.Text,
                    Website = txtWebsite.Text
                };

                entities.Manufacturers.Add(newManufacturer);
                entities.SaveChanges();
                gridManufacturers.ItemsSource = entities.Manufacturers.ToList();
                MessageBox.Show("Производитель успешно добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private bool IsPhoneNumber(string input)
        {
            foreach (char c in input)
            {
                if (!char.IsDigit(c))
                {
                    return false;
                }
            }
            return true;
        }

        private void EditManufacturer_Click(object sender, RoutedEventArgs e)
        {
            if (gridManufacturers.SelectedItem != null)
            {
                var selectedManufacturer = gridManufacturers.SelectedItem as Manufacturers;
                selectedManufacturer.Name = txtManufacturerName.Text;
                selectedManufacturer.Country = txtCountry.Text;
                selectedManufacturer.Website = txtWebsite.Text;

                entities.SaveChanges();
                gridManufacturers.Items.Refresh();
                MessageBox.Show("Производитель успешно изменен.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите производителя для изменения.");
            }
        }

        private void DeleteManufacturer_Click(object sender, RoutedEventArgs e)
        {
            if (gridManufacturers.SelectedItem != null)
            {
                var selectedManufacturer = gridManufacturers.SelectedItem as Manufacturers;
                entities.Manufacturers.Remove(selectedManufacturer);
                entities.SaveChanges();
                gridManufacturers.ItemsSource = entities.Manufacturers.ToList();
                MessageBox.Show("Производитель успешно удален.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите производителя для удаления.");
            }
        }












        private void AddManufacturerContract_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtManufacturerID.Text))
                {
                    MessageBox.Show("Введите id марки");
                    return;
                }
                if (string.IsNullOrWhiteSpace(dpStartDate2.Text))
                {
                    MessageBox.Show("Введите дату начала действия договора");
                    return;
                }
                if (string.IsNullOrWhiteSpace(dpEndDate2.Text))
                {
                    MessageBox.Show("Введите дату конца действия договора");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtTerms.Text))
                {
                    MessageBox.Show("Введите основание договора");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtManufacturerID.Text) || string.IsNullOrWhiteSpace(dpStartDate2.Text) || string.IsNullOrWhiteSpace(dpEndDate2.Text) || string.IsNullOrWhiteSpace(txtTerms.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtManufacturerID.Text))
                {
                    MessageBox.Show("ID компании должен содержать только цифры.");
                    return;
                }

                var newManufacturerContract = new ManufacturerContracts
                {
                    ManufacturerID = int.Parse(txtManufacturerID.Text),
                    StartDate = dpStartDate2.SelectedDate.Value,
                    EndDate = dpEndDate2.SelectedDate.Value,
                    Terms = txtTerms.Text
                };

                entities.ManufacturerContracts.Add(newManufacturerContract);
                entities.SaveChanges();
                gridManufacturerContracts.ItemsSource = entities.ManufacturerContracts.ToList();
                MessageBox.Show("Контракт с производителем успешно добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditManufacturerContract_Click(object sender, RoutedEventArgs e)
        {
            if (gridManufacturerContracts.SelectedItem != null)
            {
                var selectedManufacturerContract = gridManufacturerContracts.SelectedItem as ManufacturerContracts;
                selectedManufacturerContract.ManufacturerID = int.Parse(txtManufacturerID.Text);
                selectedManufacturerContract.StartDate = dpStartDate2.SelectedDate.Value;
                selectedManufacturerContract.EndDate = dpEndDate2.SelectedDate.Value;
                selectedManufacturerContract.Terms = txtTerms.Text;

                entities.SaveChanges();
                gridManufacturerContracts.Items.Refresh();
                MessageBox.Show("Контракт с производителем успешно изменен.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите контракт с производителем для изменения.");
            }
        }

        private void DeleteManufacturerContract_Click(object sender, RoutedEventArgs e)
        {
            if (gridManufacturerContracts.SelectedItem != null)
            {
                var selectedManufacturerContract = gridManufacturerContracts.SelectedItem as ManufacturerContracts;
                entities.ManufacturerContracts.Remove(selectedManufacturerContract);
                entities.SaveChanges();
                gridManufacturerContracts.ItemsSource = entities.ManufacturerContracts.ToList();
                MessageBox.Show("Контракт с производителем успешно удален.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите контракт с производителем для удаления.");
            }
        }


     


      

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            TabItem selectedTab = (sender as TabControl)?.SelectedItem as TabItem;
            switch (selectedTab?.Header)
            {
                
                case "Manufacturers":
                    gridManufacturers.ItemsSource = entities.Manufacturers.ToList();
                    break;
               
                case "ManufacturerContracts":
                    gridManufacturerContracts.ItemsSource = entities.ManufacturerContracts.ToList();
                    break;
            }
        }

        private void BackupButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Получаем текущую дату и время для создания уникального имени файла бэкапа
                string backupName = $"Backup_{DateTime.Now.ToString("yyyyMMdd_HHmmss")}.bak";

                // Указываем путь для сохранения файла бэкапа
                string backupPath = @"D:\Учёба\Практика 2-ой курс\Практическая N5\Ado.Net\" + backupName;

                // Создаем подключение к базе данных
                using (SqlConnection connection = new SqlConnection("Kobra\\SQLEXPRESS"))
                {
                    connection.Open();

                    // Создаем команду для выполнения операции бэкапа
                    using (SqlCommand command = new SqlCommand($"BACKUP DATABASE storeAuto TO DISK = '{backupPath}'", connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Бэкап базы данных успешно создан.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании бэкапа базы данных: {ex.Message}");
            }
        }


        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid dataGrid = (DataGrid)sender;

            if (dataGrid.SelectedItem != null)
            {
                // Получаем выбранный элемент из DataGrid'а
                dynamic selectedItem = dataGrid.SelectedItem;

                // Обновляем поля ввода на основе выбранного элемента
                switch (dataGrid.Name)
                {
                   
                    case "gridManufacturers":
                        txtManufacturerName.Text = selectedItem.Name;
                        txtCountry.Text = selectedItem.Country;
                        txtWebsite.Text = selectedItem.Website;
                        break;
                    

                    case "gridManufacturerContracts":
                        txtManufacturerID.Text = selectedItem.ManufacturerID.ToString();
                        dpStartDate2.SelectedDate = selectedItem.StartDate;
                        dpEndDate2.SelectedDate = selectedItem.EndDate;
                        txtTerms.Text = selectedItem.Terms;
                        break;
                }

            }
        }
    }
}
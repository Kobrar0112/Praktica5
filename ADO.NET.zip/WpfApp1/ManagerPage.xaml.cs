﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    public partial class ManagerPage : Page
    {
        private storeAutoEntities entities = new storeAutoEntities();

        public ManagerPage()
        {
            InitializeComponent();

            InitializeDataGrids();
        }

        private void InitializeDataGrids()
        {
            gridCustomers.ItemsSource = entities.Customers.ToList();
            gridCars.ItemsSource = entities.Cars.ToList();
            gridSales.ItemsSource = entities.Sales.ToList();
          
            gridInsurances.ItemsSource = entities.Insurances.ToList();
            gridLoans.ItemsSource = entities.Loans.ToList();
     


            gridCustomers.SelectionChanged += DataGrid_SelectionChanged;
            gridCars.SelectionChanged += DataGrid_SelectionChanged;
            gridSales.SelectionChanged += DataGrid_SelectionChanged;
          
            gridInsurances.SelectionChanged += DataGrid_SelectionChanged;
            gridLoans.SelectionChanged += DataGrid_SelectionChanged;
          
            this.MouseDown += Page_MouseDown;

        }


        private void Page_MouseDown(object sender, MouseButtonEventArgs e)
        {

            ClearInputFields();
        }

        private void ClearInputFields()
        {
           
            txtCustomerName.Text = string.Empty;
            txtPhone.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtMake.Text = string.Empty;
            txtModel.Text = string.Empty;
            txtYear.Text = string.Empty;
            txtPrice.Text = string.Empty;
            txtColor.Text = string.Empty;
            gridCustomers.SelectedItem = null;
            gridCars.SelectedItem = null;
            dpSaleDate.SelectedDate = null;
           
            txtCustomerID3.Text = string.Empty;
            txtLoanAmount.Text = string.Empty;
            Duration.Text = string.Empty;
            BankName.Text = string.Empty;
            txtInterestRate.Text = string.Empty;
            txtCustomerID2.Text = string.Empty;
            txtInsuranceType.Text = string.Empty;
            dpStartDate.Text = string.Empty;
            dpEndDate.Text = string.Empty;
            txtPremium.Text = string.Empty;

            txtCustomerID.Text = string.Empty;
            txtCarID.Text = string.Empty;
            dpSaleDate.SelectedDate = null;
            txtSalePrice.Text = string.Empty;
            txtNote.Text = string.Empty;
            gridSales.SelectedItem = null;

        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            Application.Current.MainWindow = mainWindow;
            NavigationService?.Navigate(null); 
        }


        private void AddCustomer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCustomerName.Text))
                {
                    MessageBox.Show("Введите имя клиента.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPhone.Text))
                {
                    MessageBox.Show("Введите телефон клиента.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtEmail.Text))
                {
                    MessageBox.Show("Введите почту клиента.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtAddress.Text))
                {
                    MessageBox.Show("Введите адрес клиента.");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtCustomerName.Name) || string.IsNullOrWhiteSpace(txtPhone.Text) || string.IsNullOrWhiteSpace(txtEmail.Text) || string.IsNullOrWhiteSpace(txtAddress.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtPhone.Text))
                {
                    MessageBox.Show("Номер телефона должен содержать только цифры.");
                    return;
                }



                var newCustomer = new Customers
                {
                    Name = txtCustomerName.Text,
                    Phone = txtPhone.Text,
                    Email = txtEmail.Text,
                    Address = txtAddress.Text
                };

                entities.Customers.Add(newCustomer);
                entities.SaveChanges();
                gridCustomers.ItemsSource = entities.Customers.ToList();
                MessageBox.Show("Клиент успешно добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }



        private bool IsPhoneNumber(string input)
        {
            foreach (char c in input)
            {
                if (!char.IsDigit(c))
                {
                    return false;
                }
            }
            return true;
        }

        private void EditCustomer_Click(object sender, RoutedEventArgs e)
        {
            if (gridCustomers.SelectedItem != null)
            {
                var selectedCustomer = gridCustomers.SelectedItem as Customers;
                selectedCustomer.Name = txtCustomerName.Text;
                selectedCustomer.Phone = txtPhone.Text;
                selectedCustomer.Email = txtEmail.Text;
                selectedCustomer.Address = txtAddress.Text;

                entities.SaveChanges();
                gridCustomers.Items.Refresh();
                MessageBox.Show("Клиент успешно изменен.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите клиента для изменения.");
            }
        }

        private void DeleteCustomer_Click(object sender, RoutedEventArgs e)
        {
            if (gridCustomers.SelectedItem != null)
            {
                var selectedCustomer = gridCustomers.SelectedItem as Customers;
                entities.Customers.Remove(selectedCustomer);
                entities.SaveChanges();
                gridCustomers.ItemsSource = entities.Customers.ToList();
                MessageBox.Show("Клиент успешно удален.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите клиента для удаления.");
            }
        }

        private void AddCar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtMake.Text))
                {
                    MessageBox.Show("Введите марку.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtModel.Text))
                {
                    MessageBox.Show("Введите модель.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtYear.Text))
                {
                    MessageBox.Show("Введите год выпуска.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPrice.Text))
                {
                    MessageBox.Show("Введите цену.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtColor.Text))
                {
                    MessageBox.Show("Введите цвет.");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtMake.Text) || string.IsNullOrWhiteSpace(txtModel.Text) || string.IsNullOrWhiteSpace(txtYear.Text) || string.IsNullOrWhiteSpace(txtPrice.Text) || string.IsNullOrWhiteSpace(txtColor.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtYear.Text))
                {
                    MessageBox.Show("Год выпуска должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtPrice.Text))
                {
                    MessageBox.Show("Цена должна содержать только цифры.");
                    return;
                }


                var newCar = new Cars
                {
                    Make = txtMake.Text,
                    Model = txtModel.Text,
                    Year = int.Parse(txtYear.Text),
                    Price = decimal.Parse(txtPrice.Text),
                    Color = txtColor.Text
                };

                entities.Cars.Add(newCar);
                entities.SaveChanges();
                gridCars.ItemsSource = entities.Cars.ToList();
                MessageBox.Show("Автомобиль успешно добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditCar_Click(object sender, RoutedEventArgs e)
        {
            if (gridCars.SelectedItem != null)
            {
                var selectedCar = gridCars.SelectedItem as Cars;
                selectedCar.Make = txtMake.Text;
                selectedCar.Model = txtModel.Text;
                selectedCar.Year = int.Parse(txtYear.Text);
                selectedCar.Price = decimal.Parse(txtPrice.Text);
                selectedCar.Color = txtColor.Text;

                entities.SaveChanges();
                gridCars.Items.Refresh();
                MessageBox.Show("Автомобиль успешно изменен.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите автомобиль для изменения.");
            }
        }

        private void DeleteCar_Click(object sender, RoutedEventArgs e)
        {
            if (gridCars.SelectedItem != null)
            {
                var selectedCar = gridCars.SelectedItem as Cars;
                entities.Cars.Remove(selectedCar);
                entities.SaveChanges();
                gridCars.ItemsSource = entities.Cars.ToList();
                MessageBox.Show("Автомобиль успешно удален.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите автомобиль для удаления.");
            }
        }

        private void AddSale_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCustomerID.Text))
                {
                    MessageBox.Show("Введите Id клиента.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtCarID.Text))
                {
                    MessageBox.Show("Введите id авто.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(dpSaleDate.Text))
                {
                    MessageBox.Show("Введите дату");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtSalePrice.Text))
                {
                    MessageBox.Show("Введите % с продажи");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtNote.Text))
                {
                    MessageBox.Show("Введите условия проджажи");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtCustomerID.Text) || string.IsNullOrWhiteSpace(txtCarID.Text) || string.IsNullOrWhiteSpace(dpSaleDate.Text) || string.IsNullOrWhiteSpace(txtSalePrice.Text) || string.IsNullOrWhiteSpace(txtNote.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtCustomerID.Text))
                {
                    MessageBox.Show("ID клиента должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtCarID.Text))
                {
                    MessageBox.Show("ID авто должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtSalePrice.Text))
                {
                    MessageBox.Show("Цена должна содержать только цифры.");
                    return;
                }

                var newSale = new Sales
                {
                    CustomerID = int.Parse(txtCustomerID.Text),
                    CarID = int.Parse(txtCarID.Text),
                    SaleDate = dpSaleDate.SelectedDate.Value,
                    SalePrice = decimal.Parse(txtSalePrice.Text),
                    Note = txtNote.Text
                };

                entities.Sales.Add(newSale);
                entities.SaveChanges();
                gridSales.ItemsSource = entities.Sales.ToList();
                MessageBox.Show("Продажа успешно добавлена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditSale_Click(object sender, RoutedEventArgs e)
        {
            if (gridSales.SelectedItem != null)
            {
                var selectedSale = gridSales.SelectedItem as Sales;
                selectedSale.CustomerID = int.Parse(txtCustomerID.Text);
                selectedSale.CarID = int.Parse(txtCarID.Text);
                selectedSale.SaleDate = dpSaleDate.SelectedDate.Value;
                selectedSale.SalePrice = decimal.Parse(txtSalePrice.Text);
                selectedSale.Note = txtNote.Text;

                entities.SaveChanges();
                gridSales.Items.Refresh();
                MessageBox.Show("Продажа успешно изменена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите продажу для изменения.");
            }
        }

        private void DeleteSale_Click(object sender, RoutedEventArgs e)
        {
            if (gridSales.SelectedItem != null)
            {
                var selectedSale = gridSales.SelectedItem as Sales;
                entities.Sales.Remove(selectedSale);
                entities.SaveChanges();
                gridSales.ItemsSource = entities.Sales.ToList();
                MessageBox.Show("Продажа успешно удалена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите продажу для удаления.");
            }
        }



        private void AddLoan_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCustomerID3.Text))
                {
                    MessageBox.Show("Введите id клиента");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtLoanAmount.Text))
                {
                    MessageBox.Show("Введите сумму кредита");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtInterestRate.Text))
                {
                    MessageBox.Show("Введите процентную ставку");
                    return;
                }
                if (string.IsNullOrWhiteSpace(Duration.Text))
                {
                    MessageBox.Show("Введите срок кредита");
                    return;
                }
                if (string.IsNullOrWhiteSpace(BankName.Text))
                {
                    MessageBox.Show("Введите имя банка");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtCustomerID3.Text) || string.IsNullOrWhiteSpace(txtLoanAmount.Text) || string.IsNullOrWhiteSpace(txtInterestRate.Text) || string.IsNullOrWhiteSpace(Duration.Text) || string.IsNullOrWhiteSpace(BankName.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(BankName.Text))
                {
                    MessageBox.Show("ID клиента должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtLoanAmount.Text))
                {
                    MessageBox.Show("Цена должна содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtInterestRate.Text))
                {
                    MessageBox.Show("Процентная ставка должна содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(Duration.Text))
                {
                    MessageBox.Show("Срок кредитования должен содержать только цифры.");
                    return;
                }

                var newLoan = new Loans
                {
                    CustomerID = int.Parse(txtCustomerID3.Text),
                    Amount = decimal.Parse(txtLoanAmount.Text),
                    InterestRate = decimal.Parse(txtInterestRate.Text),
                    Duration = int.Parse(Duration.Text),
                    BankName = BankName.Text

                };

                entities.Loans.Add(newLoan);
                entities.SaveChanges();
                gridLoans.ItemsSource = entities.Loans.ToList();
                MessageBox.Show("Запись о займе успешно добавлена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditLoan_Click(object sender, RoutedEventArgs e)
        {
            if (gridLoans.SelectedItem != null)
            {
                var selectedLoan = gridLoans.SelectedItem as Loans;
                selectedLoan.CustomerID = int.Parse(txtCustomerID3.Text);
                selectedLoan.Amount = decimal.Parse(txtLoanAmount.Text);
                selectedLoan.InterestRate = decimal.Parse(txtInterestRate.Text);
                selectedLoan.Duration = int.Parse(Duration.Text);
                selectedLoan.BankName = BankName.Text;
           

                entities.SaveChanges();
                gridLoans.Items.Refresh();
                MessageBox.Show("Запись о займе успешно изменена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запись о займе для изменения.");
            }
        }


        private void DeleteLoan_Click(object sender, RoutedEventArgs e)
        {
            if (gridLoans.SelectedItem != null)
            {
                var selectedLoan = gridLoans.SelectedItem as Loans;
                entities.Loans.Remove(selectedLoan);
                entities.SaveChanges();
                gridLoans.ItemsSource = entities.Loans.ToList();
                MessageBox.Show("Запись о займе успешно удалена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запись о займе для удаления.");
            }
        }



        private void AddInsurance_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCustomerID2.Text))
                {
                    MessageBox.Show("Введите id клиента");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtInsuranceType.Text))
                {
                    MessageBox.Show("Введите id авто");
                    return;
                }
                if (string.IsNullOrWhiteSpace(dpStartDate.Text))
                {
                    MessageBox.Show("Введите номер полиса");
                    return;
                }
                if (string.IsNullOrWhiteSpace(dpEndDate.Text))
                {
                    MessageBox.Show("Введите дату истечения срока действия полиса");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPremium.Text))
                {
                    MessageBox.Show("Введите тип полиса");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtCustomerID2.Text) || string.IsNullOrWhiteSpace(txtInsuranceType.Text) || string.IsNullOrWhiteSpace(dpStartDate.Text) || string.IsNullOrWhiteSpace(dpEndDate.Text) || string.IsNullOrWhiteSpace(txtPremium.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtCustomerID2.Text))
                {
                    MessageBox.Show("ID клиента должен содержать только цифры.");
                }
                if (!IsPhoneNumber(txtInsuranceType.Text))
                {
                    MessageBox.Show("ID авто должен содержать только цифры.");
                }
                if (!IsPhoneNumber(dpStartDate.Text))
                {
                    MessageBox.Show("Страховой полис должен содержать только цифры.");
                }


                var newInsurance = new Insurances
                {
                    CustomerID = int.Parse(txtCustomerID2.Text),
                    CarID = int.Parse(txtInsuranceType.Text),
                    PolicyNumber = dpStartDate.Text,
                    ExpiryDate = dpEndDate.SelectedDate.Value,
                    Type = txtPremium.Text
                };

                entities.Insurances.Add(newInsurance);
                entities.SaveChanges();
                gridInsurances.ItemsSource = entities.Insurances.ToList();
                MessageBox.Show("Страховой полис успешно добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditInsurance_Click(object sender, RoutedEventArgs e)
        {
            if (gridInsurances.SelectedItem != null)
            {
                var selectedInsurance = gridInsurances.SelectedItem as Insurances;
                selectedInsurance.CustomerID = int.Parse(txtCustomerID2.Text);
                selectedInsurance.CarID = int.Parse(txtInsuranceType.Text);
                selectedInsurance.PolicyNumber = dpStartDate.Text;
                selectedInsurance.ExpiryDate = dpEndDate.SelectedDate.Value;
                selectedInsurance.Type = txtPremium.Text;

                entities.SaveChanges();
                gridInsurances.Items.Refresh();
                MessageBox.Show("Страховой полис успешно изменен.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите страховой полис для изменения.");
            }
        }

        private void DeleteInsurance_Click(object sender, RoutedEventArgs e)
        {
            if (gridInsurances.SelectedItem != null)
            {
                var selectedInsurance = gridInsurances.SelectedItem as Insurances;
                entities.Insurances.Remove(selectedInsurance);
                entities.SaveChanges();
                gridInsurances.ItemsSource = entities.Insurances.ToList();
                MessageBox.Show("Страховой полис успешно удален.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите страховой полис для удаления.");
            }
        }


        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            TabItem selectedTab = (sender as TabControl)?.SelectedItem as TabItem;
            switch (selectedTab?.Header)
            {
                case "Customers":
                    gridCustomers.ItemsSource = entities.Customers.ToList();
                    break;
                case "Cars":
                    gridCars.ItemsSource = entities.Cars.ToList();
                    break;
                case "Sales":
                    gridSales.ItemsSource = entities.Sales.ToList();
                    break;
             
                case "Insurances":
                    gridInsurances.ItemsSource = entities.Insurances.ToList();
                    break;
                case "Loans":
                    gridLoans.ItemsSource = entities.Loans.ToList();
                    break;
           
            }
        }



        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid dataGrid = (DataGrid)sender;

            if (dataGrid.SelectedItem != null)
            {
                // Получаем выбранный элемент из DataGrid'а
                dynamic selectedItem = dataGrid.SelectedItem;

                // Обновляем поля ввода на основе выбранного элемента
                switch (dataGrid.Name)
                {
                    case "gridCustomers":
                        txtCustomerName.Text = selectedItem.Name;
                        txtPhone.Text = selectedItem.Phone;
                        txtEmail.Text = selectedItem.Email;
                        txtAddress.Text = selectedItem.Address;
                        break;
                    case "gridCars":
                        txtMake.Text = selectedItem.Make;
                        txtModel.Text = selectedItem.Model;
                        txtYear.Text = selectedItem.Year.ToString();
                        txtPrice.Text = selectedItem.Price.ToString();
                        txtColor.Text = selectedItem.Color;
                        break;
                    case "gridSales":
                        txtCustomerID.Text = selectedItem.CustomerID.ToString();
                        txtCarID.Text = selectedItem.CarID.ToString();
                        dpSaleDate.SelectedDate = selectedItem.SaleDate;
                        txtSalePrice.Text = selectedItem.SalePrice.ToString();
                        txtNote.Text = selectedItem.Note;
                        break;
                  
                  
                    case "gridInsurances":
                        txtCustomerID2.Text = selectedItem.CustomerID.ToString();
                        txtInsuranceType.Text = selectedItem.CarID.ToString();
                        dpStartDate.Text = selectedItem.PolicyNumber;
                        dpEndDate.SelectedDate = selectedItem.ExpiryDate;
                        txtPremium.Text = selectedItem.Type;
                        break;

                    case "gridLoans":
                        txtCustomerID3.Text = selectedItem.CustomerID.ToString();
                        txtLoanAmount.Text = selectedItem.Amount.ToString();
                        Duration.Text = selectedItem.Duration.ToString();
                        BankName.Text = selectedItem.BankName;
                        txtInterestRate.Text = selectedItem.InterestRate.ToString();
                        break;

                }

            }
        }
    }
}
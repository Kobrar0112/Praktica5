﻿using Microsoft.Win32;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace WpfApp1
{
    public class ReceiptItem
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
    }

    

    public partial class AccountantsPage : Page
    {
        private storeAutoEntities entities = new storeAutoEntities();
        private List<ReceiptItem> receiptItems = new List<ReceiptItem>();

        public AccountantsPage()
        {
            InitializeComponent();

            InitializeDataGrids();
        }

        private void InitializeDataGrids()
        {
            gridCustomers.ItemsSource = entities.Customers.ToList();
            gridCars.ItemsSource = entities.Cars.ToList();
            gridSales.ItemsSource = entities.Sales.ToList();
            gridEmployees.ItemsSource = entities.Employees.ToList();

            gridServices.ItemsSource = entities.Services.ToList();
            gridParts.ItemsSource = entities.Parts.ToList();

            gridLoans.ItemsSource = entities.Loans.ToList();
            gridReceipt.ItemsSource = entities.Receipt.ToList();
            


            gridCustomers.SelectionChanged += DataGrid_SelectionChanged;
            gridCars.SelectionChanged += DataGrid_SelectionChanged;
            gridSales.SelectionChanged += DataGrid_SelectionChanged;
            gridEmployees.SelectionChanged += DataGrid_SelectionChanged;

            gridServices.SelectionChanged += DataGrid_SelectionChanged;
            gridParts.SelectionChanged += DataGrid_SelectionChanged;

            gridLoans.SelectionChanged += DataGrid_SelectionChanged;

            this.MouseDown += Page_MouseDown;

        }

        private void AddToOrder_Click(object sender, RoutedEventArgs e)
        {
            if (gridCars.SelectedItem != null)
            {
                var selectedCar = gridCars.SelectedItem as Cars;
                var receiptItem = new ReceiptItem
                {
                    Name = selectedCar.Make + " " + selectedCar.Model,
                    Price = (decimal)selectedCar.Price
                };
                receiptItems.Add(receiptItem);

                CalculateTotalAmount();

                MessageBox.Show("Автомобиль добавлен в чек.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите автомобиль для добавления в чек.");
            }
        }

        private void CalculateTotalAmount()
        {
            decimal totalAmount = receiptItems.Sum(item => item.Price);
            txtTotalAmount.Text = totalAmount.ToString();
        }



        private void Pay_Click(object sender, RoutedEventArgs e)
        {
            if (decimal.TryParse(txtPayment.Text, out decimal paymentAmount))
            {
                decimal totalAmount = decimal.Parse(txtTotalAmount.Text);
                decimal change = paymentAmount - totalAmount;
                StringBuilder receiptBuilder = new StringBuilder();
                receiptBuilder.AppendLine("                   Store Auto");
                receiptBuilder.AppendLine($"                Кассовый чек №{GetReceiptID()}"); 
                foreach (var item in receiptItems)
                {
                    receiptBuilder.AppendLine($"     {item.Name}\t-\t{item.Price}");
                }
                receiptBuilder.AppendLine();
                receiptBuilder.AppendLine($"Итого к оплате: {totalAmount}");
                receiptBuilder.AppendLine($"Внесено: {paymentAmount}");
                receiptBuilder.AppendLine($"Сдача: {change}");

            
                string receiptText = receiptBuilder.ToString();
                string fileName = "receipt.txt";
                string filePath = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), fileName);

                File.WriteAllText(filePath, receiptText);

          
                SaveReceiptToDatabase(receiptText, totalAmount, paymentAmount, change);

             
                receiptItems.Clear();

                txtTotalAmount.Text = string.Empty;
                txtPayment.Text = string.Empty;

                MessageBox.Show($"Оплата произведена успешно. Чек сохранен как в базу данных, так и на рабочем столе в файле {fileName}.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите корректную сумму в поле 'Внесено'.");
            }
        }

        private string GetReceiptID()
        {
        
            int receiptID = entities.Receipt.Any() ? entities.Receipt.Max(r => r.ReceiptID) + 1 : 1;
            return receiptID.ToString();
        }

        private void SaveReceiptToDatabase(string receiptText, decimal totalAmount, decimal paymentAmount, decimal changeAmount)
        {

            Receipt receipt = new Receipt
            {
                ProgramName = "Store Auto",
                ItemName = receiptItems.Select(item => item.Name).FirstOrDefault(),
                Price = receiptItems.Select(item => item.Price).FirstOrDefault(),
                TotalAmount = totalAmount,
                AmountPaid = paymentAmount,
                ChangeAmount = changeAmount
            };

            entities.Receipt.Add(receipt);
            entities.SaveChanges();

  
            receiptText = receiptText.Replace("ReceiptID", receipt.ReceiptID.ToString());

            gridReceipt.ItemsSource = entities.Receipt.ToList();
        }

        private void DownloadReceipt_Click(object sender, RoutedEventArgs e)
        {
            if (gridReceipt.SelectedItem != null)
            {
                var selectedReceipt = gridReceipt.SelectedItem as Receipt;
                string receiptText = GenerateReceiptText(selectedReceipt);

                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "Text files (*.txt)|*.txt";
                if (saveFileDialog.ShowDialog() == true)
                {
                    File.WriteAllText(saveFileDialog.FileName, receiptText);
                    MessageBox.Show($"Чек успешно сохранен в файле {saveFileDialog.FileName}.");
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите чек для скачивания.");
            }
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            receiptItems.Clear();
            txtTotalAmount.Text = string.Empty;
            txtPayment.Text = string.Empty;
        }

        private string GenerateReceiptText(Receipt receipt)
        {
            StringBuilder receiptBuilder = new StringBuilder();
            receiptBuilder.AppendLine("           	   Store Auto");
            receiptBuilder.AppendLine($"     	  Кассовый чек №{receipt.ReceiptID}");
            receiptBuilder.AppendLine($"     {receipt.ItemName}\t-\t{receipt.Price}");
            receiptBuilder.AppendLine();
            receiptBuilder.AppendLine($"Итого к оплате: {receipt.TotalAmount}");
            receiptBuilder.AppendLine($"Внесено: {receipt.AmountPaid}");
            receiptBuilder.AppendLine($"Сдача: {receipt.ChangeAmount}");

            return receiptBuilder.ToString();
        }

        private void Page_MouseDown(object sender, MouseButtonEventArgs e)
        {
            ClearInputFields();
        }

        private void ClearInputFields()
        {
            txtCustomerName.Text = string.Empty;
            txtPhone.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtMake.Text = string.Empty;
            txtModel.Text = string.Empty;
            txtYear.Text = string.Empty;
            txtPrice.Text = string.Empty;
            txtColor.Text = string.Empty;
            gridCustomers.SelectedItem = null;
            gridCars.SelectedItem = null;
            dpSaleDate.SelectedDate = null;
            dpHireDate.SelectedDate = null;
            txtCustomerID3.Text = string.Empty;
            txtLoanAmount.Text = string.Empty;
            Duration.Text = string.Empty;
            BankName.Text = string.Empty;
            txtInterestRate.Text = string.Empty;
            txtEmployeeName.Text = string.Empty;
            txtPosition.Text = string.Empty;
            txtSalary.Text = string.Empty;
            dpHireDate.SelectedDate = null;
            txtDepartment.Text = string.Empty;
            txtLogin.Text = string.Empty;
            txtPassword.Text = string.Empty;
            txtCarID1.Text = string.Empty;
            dpServiceDate.SelectedDate = null;
            txtDescription.Text = string.Empty;
            txtCost.Text = string.Empty;
            txtStatus.Text = string.Empty;
            gridServices.SelectedItem = null;
            txtPartName.Text = string.Empty;
            txtPartDescription.Text = string.Empty;
            txtPartPrice.Text = string.Empty;
            txtPartCategory.Text = string.Empty;
            gridParts.SelectedItem = null;
            txtCustomerID.Text = string.Empty;
            txtCarID.Text = string.Empty;
            dpSaleDate.SelectedDate = null;
            txtSalePrice.Text = string.Empty;
            txtNote.Text = string.Empty;
            gridSales.SelectedItem = null;
        }

        private void ImportData_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "JSON files (*.json)|*.json";
            if (openFileDialog.ShowDialog() == true)
            {
                string jsonContent = File.ReadAllText(openFileDialog.FileName);

                var customers = JsonConvert.DeserializeObject<List<Customers>>(jsonContent);
                var cars = JsonConvert.DeserializeObject<List<Cars>>(jsonContent);
                var sales = JsonConvert.DeserializeObject<List<Sales>>(jsonContent);

                entities.Customers.AddRange(customers);
                entities.Cars.AddRange(cars);
                entities.Sales.AddRange(sales);
                entities.SaveChanges();

                gridCustomers.ItemsSource = entities.Customers.ToList();
                gridCars.ItemsSource = entities.Cars.ToList();
                gridSales.ItemsSource = entities.Sales.ToList();

                MessageBox.Show("Данные импортированы успешно.");
            }
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            Application.Current.MainWindow = mainWindow;
            NavigationService?.Navigate(null);
        }

        private void AddCustomer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCustomerName.Text))
                {
                    MessageBox.Show("Введите имя клиента.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPhone.Text))
                {
                    MessageBox.Show("Введите телефон клиента.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtEmail.Text))
                {
                    MessageBox.Show("Введите почту клиента.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtAddress.Text))
                {
                    MessageBox.Show("Введите адрес клиента.");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtCustomerName.Name) || string.IsNullOrWhiteSpace(txtPhone.Text) || string.IsNullOrWhiteSpace(txtEmail.Text) || string.IsNullOrWhiteSpace(txtAddress.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtPhone.Text))
                {
                    MessageBox.Show("Номер телефона должен содержать только цифры.");
                    return;
                }



                var newCustomer = new Customers
                {
                    Name = txtCustomerName.Text,
                    Phone = txtPhone.Text,
                    Email = txtEmail.Text,
                    Address = txtAddress.Text
                };

                entities.Customers.Add(newCustomer);
                entities.SaveChanges();
                gridCustomers.ItemsSource = entities.Customers.ToList();
                MessageBox.Show("Клиент успешно добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private bool IsPhoneNumber(string input)
        {
            foreach (char c in input)
            {
                if (!char.IsDigit(c))
                {
                    return false;
                }
            }
            return true;
        }


        private void EditCustomer_Click(object sender, RoutedEventArgs e)
        {
            if (gridCustomers.SelectedItem != null)
            {
                var selectedCustomer = gridCustomers.SelectedItem as Customers;
                selectedCustomer.Name = txtCustomerName.Text;
                selectedCustomer.Phone = txtPhone.Text;
                selectedCustomer.Email = txtEmail.Text;
                selectedCustomer.Address = txtAddress.Text;

                entities.SaveChanges();
                gridCustomers.Items.Refresh();
                MessageBox.Show("Клиент успешно изменен.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите клиента для изменения.");
            }
        }

        private void DeleteCustomer_Click(object sender, RoutedEventArgs e)
        {
            if (gridCustomers.SelectedItem != null)
            {
                var selectedCustomer = gridCustomers.SelectedItem as Customers;
                entities.Customers.Remove(selectedCustomer);
                entities.SaveChanges();
                gridCustomers.ItemsSource = entities.Customers.ToList();
                MessageBox.Show("Клиент успешно удален.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите клиента для удаления.");
            }
        }

        private void AddCar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtMake.Text))
                {
                    MessageBox.Show("Введите марку.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtModel.Text))
                {
                    MessageBox.Show("Введите модель.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtYear.Text))
                {
                    MessageBox.Show("Введите год выпуска.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPrice.Text))
                {
                    MessageBox.Show("Введите цену.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtColor.Text))
                {
                    MessageBox.Show("Введите цвет.");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtMake.Text) || string.IsNullOrWhiteSpace(txtModel.Text) || string.IsNullOrWhiteSpace(txtYear.Text) || string.IsNullOrWhiteSpace(txtPrice.Text) || string.IsNullOrWhiteSpace(txtColor.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtYear.Text))
                {
                    MessageBox.Show("Год выпуска должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtPrice.Text))
                {
                    MessageBox.Show("Цена должна содержать только цифры.");
                    return;
                }


                var newCar = new Cars
                {
                    Make = txtMake.Text,
                    Model = txtModel.Text,
                    Year = int.Parse(txtYear.Text),
                    Price = decimal.Parse(txtPrice.Text),
                    Color = txtColor.Text
                };

                entities.Cars.Add(newCar);
                entities.SaveChanges();
                gridCars.ItemsSource = entities.Cars.ToList();
                MessageBox.Show("Автомобиль успешно добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditCar_Click(object sender, RoutedEventArgs e)
        {
            if (gridCars.SelectedItem != null)
            {
                var selectedCar = gridCars.SelectedItem as Cars;
                selectedCar.Make = txtMake.Text;
                selectedCar.Model = txtModel.Text;
                selectedCar.Year = int.Parse(txtYear.Text);
                selectedCar.Price = decimal.Parse(txtPrice.Text);
                selectedCar.Color = txtColor.Text;

                entities.SaveChanges();
                gridCars.Items.Refresh();
                MessageBox.Show("Автомобиль успешно изменен.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите автомобиль для изменения.");
            }
        }

        private void DeleteCar_Click(object sender, RoutedEventArgs e)
        {
            if (gridCars.SelectedItem != null)
            {
                var selectedCar = gridCars.SelectedItem as Cars;
                entities.Cars.Remove(selectedCar);
                entities.SaveChanges();
                gridCars.ItemsSource = entities.Cars.ToList();
                MessageBox.Show("Автомобиль успешно удален.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите автомобиль для удаления.");
            }
        }

        private void AddSale_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCustomerID.Text))
                {
                    MessageBox.Show("Введите Id клиента.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtCarID.Text))
                {
                    MessageBox.Show("Введите id авто.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(dpSaleDate.Text))
                {
                    MessageBox.Show("Введите дату");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtSalePrice.Text))
                {
                    MessageBox.Show("Введите % с продажи");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtNote.Text))
                {
                    MessageBox.Show("Введите условия проджажи");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtCustomerID.Text) || string.IsNullOrWhiteSpace(txtCarID.Text) || string.IsNullOrWhiteSpace(dpSaleDate.Text) || string.IsNullOrWhiteSpace(txtSalePrice.Text) || string.IsNullOrWhiteSpace(txtNote.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtCustomerID.Text))
                {
                    MessageBox.Show("ID клиента должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtCarID.Text))
                {
                    MessageBox.Show("ID авто должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtSalePrice.Text))
                {
                    MessageBox.Show("Цена должна содержать только цифры.");
                    return;
                }

                var newSale = new Sales
                {
                    CustomerID = int.Parse(txtCustomerID.Text),
                    CarID = int.Parse(txtCarID.Text),
                    SaleDate = dpSaleDate.SelectedDate.Value,
                    SalePrice = decimal.Parse(txtSalePrice.Text),
                    Note = txtNote.Text
                };

                entities.Sales.Add(newSale);
                entities.SaveChanges();
                gridSales.ItemsSource = entities.Sales.ToList();
                MessageBox.Show("Продажа успешно добавлена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditSale_Click(object sender, RoutedEventArgs e)
        {
            if (gridSales.SelectedItem != null)
            {
                var selectedSale = gridSales.SelectedItem as Sales;
                selectedSale.CustomerID = int.Parse(txtCustomerID.Text);
                selectedSale.CarID = int.Parse(txtCarID.Text);
                selectedSale.SaleDate = dpSaleDate.SelectedDate.Value;
                selectedSale.SalePrice = decimal.Parse(txtSalePrice.Text);
                selectedSale.Note = txtNote.Text;

                entities.SaveChanges();
                gridSales.Items.Refresh();
                MessageBox.Show("Продажа успешно изменена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите продажу для изменения.");
            }
        }

        private void DeleteSale_Click(object sender, RoutedEventArgs e)
        {
            if (gridSales.SelectedItem != null)
            {
                var selectedSale = gridSales.SelectedItem as Sales;
                entities.Sales.Remove(selectedSale);
                entities.SaveChanges();
                gridSales.ItemsSource = entities.Sales.ToList();
                MessageBox.Show("Продажа успешно удалена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите продажу для удаления.");
            }
        }

        private void AddEmployee_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtEmployeeName.Text))
                {
                    MessageBox.Show("Введите имя работника.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPosition.Text))
                {
                    MessageBox.Show("Введите должность работника.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(dpHireDate.Text))
                {
                    MessageBox.Show("Выберите дату");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPosition.Text))
                {
                    MessageBox.Show("Выберите должность");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtSalary.Text))
                {
                    MessageBox.Show("Введите ЗП");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtDepartment.Text))
                {
                    MessageBox.Show("Выберите отдел");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtLogin.Text))
                {
                    MessageBox.Show("Введите логин работника");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPassword.Text))
                {
                    MessageBox.Show("Введите пароль работника");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtEmployeeName.Text) || string.IsNullOrWhiteSpace(txtPosition.Text) || string.IsNullOrWhiteSpace(txtSalary.Text) || string.IsNullOrWhiteSpace(dpHireDate.Text) || string.IsNullOrWhiteSpace(txtDepartment.Text) || string.IsNullOrWhiteSpace(txtLogin.Text) || string.IsNullOrWhiteSpace(txtPassword.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtSalary.Text))
                {
                    MessageBox.Show("Зарплата должна содержать только цифры.");
                    return;
                }
                var existingEmployee = entities.Employees.FirstOrDefault(emp => emp.Login == txtLogin.Text);
                if (existingEmployee != null)
                {
                    MessageBox.Show("Сотрудник с таким логином уже существует.");
                    return;
                }

                var newEmployee = new Employees
                {
                    Name = txtEmployeeName.Text,
                    Position = txtPosition.Text,
                    Salary = decimal.Parse(txtSalary.Text),
                    HireDate = dpHireDate.SelectedDate.Value,
                    Department = txtDepartment.Text,
                    Login = txtLogin.Text,
                    Password = txtPassword.Text
                };

                entities.Employees.Add(newEmployee);
                entities.SaveChanges();
                gridEmployees.ItemsSource = entities.Employees.ToList();
                MessageBox.Show("Сотрудник успешно добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditEmployee_Click(object sender, RoutedEventArgs e)
        {
            if (gridEmployees.SelectedItem != null)
            {
                var selectedEmployee = gridEmployees.SelectedItem as Employees;
                selectedEmployee.Name = txtEmployeeName.Text;
                selectedEmployee.Position = txtPosition.Text;
                selectedEmployee.Salary = decimal.Parse(txtSalary.Text);
                selectedEmployee.HireDate = dpHireDate.SelectedDate.Value;
                selectedEmployee.Department = txtDepartment.Text;
                selectedEmployee.Login = txtLogin.Text;
                selectedEmployee.Password = txtPassword.Text;

                entities.SaveChanges();
                gridEmployees.Items.Refresh();
                MessageBox.Show("Сотрудник успешно изменен.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите сотрудника для изменения.");
            }
        }

        private void DeleteEmployee_Click(object sender, RoutedEventArgs e)
        {
            if (gridEmployees.SelectedItem != null)
            {
                var selectedEmployee = gridEmployees.SelectedItem as Employees;
                entities.Employees.Remove(selectedEmployee);
                entities.SaveChanges();
                gridEmployees.ItemsSource = entities.Employees.ToList();
                MessageBox.Show("Сотрудник успешно удален.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите сотрудника для удаления.");
            }
        }



         private void AddPart_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtPartName.Text))
                {
                    MessageBox.Show("Введите категорию запчасти.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPartDescription.Text))
                {
                    MessageBox.Show("Введите название запчасти.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPartPrice.Text))
                {
                    MessageBox.Show("Введите цену");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPartCategory.Text))
                {
                    MessageBox.Show("Введите категорию");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtPartName.Text) || string.IsNullOrWhiteSpace(txtPartDescription.Text) || string.IsNullOrWhiteSpace(txtPartPrice.Text) || string.IsNullOrWhiteSpace(txtPartCategory.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtPartPrice.Text))
                {
                    MessageBox.Show("Цена должна содержать только цифры.");
                    return;
                }

                var newPart = new Parts
                {
                    Name = txtPartName.Text,
                    Description = txtPartDescription.Text,
                    Price = decimal.Parse(txtPartPrice.Text),
                    Category = txtPartCategory.Text
                };

                entities.Parts.Add(newPart);
                entities.SaveChanges();
                gridParts.ItemsSource = entities.Parts.ToList();
                MessageBox.Show("Запчасть успешно добавлена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditPart_Click(object sender, RoutedEventArgs e)
        {
            if (gridParts.SelectedItem != null)
            {
                var selectedPart = gridParts.SelectedItem as Parts;
                selectedPart.Name = txtPartName.Text;
                selectedPart.Description = txtPartDescription.Text;
                selectedPart.Price = decimal.Parse(txtPartPrice.Text);
                selectedPart.Category = txtPartCategory.Text;

                entities.SaveChanges();
                gridParts.Items.Refresh();
                MessageBox.Show("Запчасть успешно изменена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запчасть для изменения.");
            }
        }

        private void DeletePart_Click(object sender, RoutedEventArgs e)
        {
            if (gridParts.SelectedItem != null)
            {
                var selectedPart = gridParts.SelectedItem as Parts;
                entities.Parts.Remove(selectedPart);
                entities.SaveChanges();
                gridParts.ItemsSource = entities.Parts.ToList();
                MessageBox.Show("Запчасть успешно удалена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запчасть для удаления.");
            }
        }


        private void AddService_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCarID1.Text))
                {
                    MessageBox.Show("Введите id авто.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(dpServiceDate.Text))
                {
                    MessageBox.Show("Выберите дату");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtDescription.Text))
                {
                    MessageBox.Show("Введите услугу");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtCost.Text))
                {
                    MessageBox.Show("Введите цену");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtStatus.Text))
                {
                    MessageBox.Show("Введите статус");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtCarID1.Text) || string.IsNullOrWhiteSpace(dpServiceDate.Text) || string.IsNullOrWhiteSpace(txtDescription.Text) || string.IsNullOrWhiteSpace(txtCost.Text) || string.IsNullOrWhiteSpace(txtStatus.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtCarID1.Text))
                {
                    MessageBox.Show("ID авто должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtCost.Text))
                {
                    MessageBox.Show("Цена должна содержать только цифры.");
                    return;
                }

                var newService = new Services
                {
                    CarID = int.Parse(txtCarID1.Text),
                    ServiceDate = dpServiceDate.SelectedDate.Value,
                    Description = txtDescription.Text,
                    Cost = decimal.Parse(txtCost.Text),
                    Status = txtStatus.Text
                };

                entities.Services.Add(newService);
                entities.SaveChanges();
                gridServices.ItemsSource = entities.Services.ToList();
                MessageBox.Show("Сервисная работа успешно добавлена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditService_Click(object sender, RoutedEventArgs e)
        {
            if (gridServices.SelectedItem != null)
            {
                var selectedService = gridServices.SelectedItem as Services;
                selectedService.CarID = int.Parse(txtCarID1.Text);
                selectedService.ServiceDate = dpServiceDate.SelectedDate.Value;
                selectedService.Description = txtDescription.Text;
                selectedService.Cost = decimal.Parse(txtCost.Text);
                selectedService.Status = txtStatus.Text;

                entities.SaveChanges();
                gridServices.Items.Refresh();
                MessageBox.Show("Сервисная работа успешно изменена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите сервисную работу для изменения.");
            }
        }

        private void DeleteService_Click(object sender, RoutedEventArgs e)
        {
            if (gridServices.SelectedItem != null)
            {
                var selectedService = gridServices.SelectedItem as Services;
                entities.Services.Remove(selectedService);
                entities.SaveChanges();
                gridServices.ItemsSource = entities.Services.ToList();
                MessageBox.Show("Сервисная работа успешно удалена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите сервисную работу для удаления.");
            }
        }




        private void AddLoan_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCustomerID3.Text))
                {
                    MessageBox.Show("Введите id клиента");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtLoanAmount.Text))
                {
                    MessageBox.Show("Введите сумму кредита");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtInterestRate.Text))
                {
                    MessageBox.Show("Введите процентную ставку");
                    return;
                }
                if (string.IsNullOrWhiteSpace(Duration.Text))
                {
                    MessageBox.Show("Введите срок кредита");
                    return;
                }
                if (string.IsNullOrWhiteSpace(BankName.Text))
                {
                    MessageBox.Show("Введите имя банка");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtCustomerID3.Text) || string.IsNullOrWhiteSpace(txtLoanAmount.Text) || string.IsNullOrWhiteSpace(txtInterestRate.Text) || string.IsNullOrWhiteSpace(Duration.Text) || string.IsNullOrWhiteSpace(BankName.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(BankName.Text))
                {
                    MessageBox.Show("ID клиента должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtLoanAmount.Text))
                {
                    MessageBox.Show("Цена должна содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtInterestRate.Text))
                {
                    MessageBox.Show("Процентная ставка должна содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(Duration.Text))
                {
                    MessageBox.Show("Срок кредитования должен содержать только цифры.");
                    return;
                }

                var newLoan = new Loans
                {
                    CustomerID = int.Parse(txtCustomerID3.Text),
                    Amount = decimal.Parse(txtLoanAmount.Text),
                    InterestRate = decimal.Parse(txtInterestRate.Text),
                    Duration = int.Parse(Duration.Text),
                    BankName = BankName.Text

                };

                entities.Loans.Add(newLoan);
                entities.SaveChanges();
                gridLoans.ItemsSource = entities.Loans.ToList();
                MessageBox.Show("Запись о займе успешно добавлена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditLoan_Click(object sender, RoutedEventArgs e)
        {
            if (gridLoans.SelectedItem != null)
            {
                var selectedLoan = gridLoans.SelectedItem as Loans;
                selectedLoan.CustomerID = int.Parse(txtCustomerID3.Text);
                selectedLoan.Amount = decimal.Parse(txtLoanAmount.Text);
                selectedLoan.InterestRate = decimal.Parse(txtInterestRate.Text);
                selectedLoan.Duration = int.Parse(Duration.Text);
                selectedLoan.BankName = BankName.Text;
           

                entities.SaveChanges();
                gridLoans.Items.Refresh();
                MessageBox.Show("Запись о займе успешно изменена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запись о займе для изменения.");
            }
        }

        // Удаление выбранной записи из таблицы Loans
        private void DeleteLoan_Click(object sender, RoutedEventArgs e)
        {
            if (gridLoans.SelectedItem != null)
            {
                var selectedLoan = gridLoans.SelectedItem as Loans;
                entities.Loans.Remove(selectedLoan);
                entities.SaveChanges();
                gridLoans.ItemsSource = entities.Loans.ToList();
                MessageBox.Show("Запись о займе успешно удалена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запись о займе для удаления.");
            }
        }



      

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            TabItem selectedTab = (sender as TabControl)?.SelectedItem as TabItem;
            switch (selectedTab?.Header)
            {
                case "Customers":
                    gridCustomers.ItemsSource = entities.Customers.ToList();
                    break;
                case "Cars":
                    gridCars.ItemsSource = entities.Cars.ToList();
                    break;
                case "Sales":
                    gridSales.ItemsSource = entities.Sales.ToList();
                    break;
                case "Employees":
                    gridEmployees.ItemsSource = entities.Employees.ToList();
                    break;
            
                case "Services":
                    gridServices.ItemsSource = entities.Services.ToList();
                    break;
                case "Parts":
                    gridParts.ItemsSource = entities.Parts.ToList();
                    break;
               
                case "Loans":
                    gridLoans.ItemsSource = entities.Loans.ToList();
                    break;
                
            }
        }



        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid dataGrid = (DataGrid)sender;

            if (dataGrid.SelectedItem != null)
            {
                // Получаем выбранный элемент из DataGrid'а
                dynamic selectedItem = dataGrid.SelectedItem;

                // Обновляем поля ввода на основе выбранного элемента
                switch (dataGrid.Name)
                {
                    case "gridCustomers":
                        txtCustomerName.Text = selectedItem.Name;
                        txtPhone.Text = selectedItem.Phone;
                        txtEmail.Text = selectedItem.Email;
                        txtAddress.Text = selectedItem.Address;
                        break;
                    case "gridCars":
                        txtMake.Text = selectedItem.Make;
                        txtModel.Text = selectedItem.Model;
                        txtYear.Text = selectedItem.Year.ToString();
                        txtPrice.Text = selectedItem.Price.ToString();
                        txtColor.Text = selectedItem.Color;
                        break;
                    case "gridSales":
                        txtCustomerID.Text = selectedItem.CustomerID.ToString();
                        txtCarID.Text = selectedItem.CarID.ToString();
                        dpSaleDate.SelectedDate = selectedItem.SaleDate;
                        txtSalePrice.Text = selectedItem.SalePrice.ToString();
                        txtNote.Text = selectedItem.Note;
                        break;
                    case "gridEmployees":
                        txtEmployeeName.Text = selectedItem.Name;
                        txtPosition.Text = selectedItem.Position;
                        txtSalary.Text = selectedItem.Salary.ToString();
                        dpHireDate.SelectedDate = selectedItem.HireDate;
                        txtDepartment.Text = selectedItem.Department.ToString();
                        txtLogin.Text = selectedItem.Login.ToString();
                        txtPassword.Text = selectedItem.Password.ToString();
                        break;
                   
                    case "gridServices":
                        txtCarID1.Text = selectedItem.CarID.ToString();
                        dpServiceDate.SelectedDate = selectedItem.ServiceDate;
                        txtDescription.Text = selectedItem.Description;
                        txtCost.Text = selectedItem.Cost.ToString();
                        txtStatus.Text = selectedItem.Status;
                        break;
                    case "gridParts":
                        txtPartName.Text = selectedItem.Name;
                        txtPartDescription.Text = selectedItem.Description;
                        txtPartPrice.Text = selectedItem.Price.ToString();
                        txtPartCategory.Text = selectedItem.Category;
                        break;
                   
                    case "gridLoans":
                        txtCustomerID3.Text = selectedItem.CustomerID.ToString();
                        txtLoanAmount.Text = selectedItem.Amount.ToString();
                        Duration.Text = selectedItem.Duration.ToString();
                        BankName.Text = selectedItem.BankName;
                        txtInterestRate.Text = selectedItem.InterestRate.ToString();
                        break;


                   
                }

            }
        }
    }
}
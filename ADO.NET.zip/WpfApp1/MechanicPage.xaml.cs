﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    public partial class MechanicPage : Page
    {
        private storeAutoEntities entities = new storeAutoEntities();

        public MechanicPage()
        {
            InitializeComponent();

            InitializeDataGrids();
        }




        private void InitializeDataGrids()
        {
            gridCars.ItemsSource = entities.Cars.ToList();
            gridServices.ItemsSource = entities.Services.ToList();
            gridParts.ItemsSource = entities.Parts.ToList();
            gridSuppliers.ItemsSource = entities.Suppliers.ToList();
            gridPartSuppliers.ItemsSource = entities.PartSuppliers.ToList();
            gridWarehouse.ItemsSource = entities.Warehouse.ToList();
            gridComplaints.ItemsSource = entities.Complaints.ToList();



            gridCars.SelectionChanged += DataGrid_SelectionChanged;
            gridServices.SelectionChanged += DataGrid_SelectionChanged;
            gridParts.SelectionChanged += DataGrid_SelectionChanged;
            gridSuppliers.SelectionChanged += DataGrid_SelectionChanged;
            gridPartSuppliers.SelectionChanged += DataGrid_SelectionChanged;
            gridWarehouse.SelectionChanged += DataGrid_SelectionChanged;
            gridComplaints.SelectionChanged += DataGrid_SelectionChanged;
           
            this.MouseDown += Page_MouseDown;

        }


        private void Page_MouseDown(object sender, MouseButtonEventArgs e)
        {

            ClearInputFields();
        }

        private void ClearInputFields()
        {
           
          
            txtMake.Text = string.Empty;
            txtModel.Text = string.Empty;
            txtYear.Text = string.Empty;
            txtPrice.Text = string.Empty;
            txtColor.Text = string.Empty;
         
            gridCars.SelectedItem = null;

            txtCarID1.Text = string.Empty;
            dpServiceDate.SelectedDate = null;
            txtDescription.Text = string.Empty;
            txtCost.Text = string.Empty;
            txtStatus.Text = string.Empty;
            gridServices.SelectedItem = null;

            txtPartName.Text = string.Empty;
            txtPartDescription.Text = string.Empty;
            txtPartPrice.Text = string.Empty;
            txtPartCategory.Text = string.Empty;
            gridParts.SelectedItem = null;


            txtSupplierName.Text = string.Empty;
            txtContactName.Text = string.Empty;
            txtSupplierPhone.Text = string.Empty;
            txtSupplierAddress.Text = string.Empty;
            txtSupplierEmail.Text = string.Empty;
            gridSuppliers.SelectedItem = null;

            txtPartID.Text = string.Empty;
            txtSupplierID.Text = string.Empty;
            txtPartSupplierPrice.Text = string.Empty;
            txtDeliveryStatus.Text = string.Empty;
            gridPartSuppliers.SelectedItem = null;

            txtWarehousePartID.Text = string.Empty;
            txtQuantity.Text = string.Empty;
            txtLocation.Text = string.Empty;
            gridWarehouse.SelectedItem = null;

            txtCustomerID1.Text = string.Empty;
            txtComplaintDescription.Text = string.Empty;
            txtResolution.Text = string.Empty;
            txtComplaintStatus.Text = string.Empty;
            gridComplaints.SelectedItem = null;
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            Application.Current.MainWindow = mainWindow;
            NavigationService?.Navigate(null); 
        }




        private void AddCar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtMake.Text))
                {
                    MessageBox.Show("Введите марку.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtModel.Text))
                {
                    MessageBox.Show("Введите модель.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtYear.Text))
                {
                    MessageBox.Show("Введите год выпуска.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPrice.Text))
                {
                    MessageBox.Show("Введите цену.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtColor.Text))
                {
                    MessageBox.Show("Введите цвет.");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtMake.Text) || string.IsNullOrWhiteSpace(txtModel.Text) || string.IsNullOrWhiteSpace(txtYear.Text) || string.IsNullOrWhiteSpace(txtPrice.Text) || string.IsNullOrWhiteSpace(txtColor.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtYear.Text))
                {
                    MessageBox.Show("Год выпуска должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtPrice.Text))
                {
                    MessageBox.Show("Цена должна содержать только цифры.");
                    return;
                }


                var newCar = new Cars
                {
                    Make = txtMake.Text,
                    Model = txtModel.Text,
                    Year = int.Parse(txtYear.Text),
                    Price = decimal.Parse(txtPrice.Text),
                    Color = txtColor.Text
                };

                entities.Cars.Add(newCar);
                entities.SaveChanges();
                gridCars.ItemsSource = entities.Cars.ToList();
                MessageBox.Show("Автомобиль успешно добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private bool IsPhoneNumber(string input)
        {
            foreach (char c in input)
            {
                if (!char.IsDigit(c))
                {
                    return false;
                }
            }
            return true;
        }

        private void EditCar_Click(object sender, RoutedEventArgs e)
        {
            if (gridCars.SelectedItem != null)
            {
                var selectedCar = gridCars.SelectedItem as Cars;
                selectedCar.Make = txtMake.Text;
                selectedCar.Model = txtModel.Text;
                selectedCar.Year = int.Parse(txtYear.Text);
                selectedCar.Price = decimal.Parse(txtPrice.Text);
                selectedCar.Color = txtColor.Text;

                entities.SaveChanges();
                gridCars.Items.Refresh();
                MessageBox.Show("Автомобиль успешно изменен.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите автомобиль для изменения.");
            }
        }

        private void DeleteCar_Click(object sender, RoutedEventArgs e)
        {
            if (gridCars.SelectedItem != null)
            {
                var selectedCar = gridCars.SelectedItem as Cars;
                entities.Cars.Remove(selectedCar);
                entities.SaveChanges();
                gridCars.ItemsSource = entities.Cars.ToList();
                MessageBox.Show("Автомобиль успешно удален.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите автомобиль для удаления.");
            }
        }




        private void AddPart_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtPartName.Text))
                {
                    MessageBox.Show("Введите категорию запчасти.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPartDescription.Text))
                {
                    MessageBox.Show("Введите название запчасти.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPartPrice.Text))
                {
                    MessageBox.Show("Введите цену");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPartCategory.Text))
                {
                    MessageBox.Show("Введите категорию");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtPartName.Text) || string.IsNullOrWhiteSpace(txtPartDescription.Text) || string.IsNullOrWhiteSpace(txtPartPrice.Text) || string.IsNullOrWhiteSpace(txtPartCategory.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtPartPrice.Text))
                {
                    MessageBox.Show("Цена должна содержать только цифры.");
                    return;
                }

                var newPart = new Parts
                {
                    Name = txtPartName.Text,
                    Description = txtPartDescription.Text,
                    Price = decimal.Parse(txtPartPrice.Text),
                    Category = txtPartCategory.Text
                };

                entities.Parts.Add(newPart);
                entities.SaveChanges();
                gridParts.ItemsSource = entities.Parts.ToList();
                MessageBox.Show("Запчасть успешно добавлена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditPart_Click(object sender, RoutedEventArgs e)
        {
            if (gridParts.SelectedItem != null)
            {
                var selectedPart = gridParts.SelectedItem as Parts;
                selectedPart.Name = txtPartName.Text;
                selectedPart.Description = txtPartDescription.Text;
                selectedPart.Price = decimal.Parse(txtPartPrice.Text);
                selectedPart.Category = txtPartCategory.Text;

                entities.SaveChanges();
                gridParts.Items.Refresh();
                MessageBox.Show("Запчасть успешно изменена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запчасть для изменения.");
            }
        }

        private void DeletePart_Click(object sender, RoutedEventArgs e)
        {
            if (gridParts.SelectedItem != null)
            {
                var selectedPart = gridParts.SelectedItem as Parts;
                entities.Parts.Remove(selectedPart);
                entities.SaveChanges();
                gridParts.ItemsSource = entities.Parts.ToList();
                MessageBox.Show("Запчасть успешно удалена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запчасть для удаления.");
            }
        }


        private void AddService_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCarID1.Text))
                {
                    MessageBox.Show("Введите id авто.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(dpServiceDate.Text))
                {
                    MessageBox.Show("Выберите дату");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtDescription.Text))
                {
                    MessageBox.Show("Введите услугу");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtCost.Text))
                {
                    MessageBox.Show("Введите цену");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtStatus.Text))
                {
                    MessageBox.Show("Введите статус");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtCarID1.Text) || string.IsNullOrWhiteSpace(dpServiceDate.Text) || string.IsNullOrWhiteSpace(txtDescription.Text) || string.IsNullOrWhiteSpace(txtCost.Text) || string.IsNullOrWhiteSpace(txtStatus.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtCarID1.Text))
                {
                    MessageBox.Show("ID авто должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtCost.Text))
                {
                    MessageBox.Show("Цена должна содержать только цифры.");
                    return;
                }

                var newService = new Services
                {
                    CarID = int.Parse(txtCarID1.Text),
                    ServiceDate = dpServiceDate.SelectedDate.Value,
                    Description = txtDescription.Text,
                    Cost = decimal.Parse(txtCost.Text),
                    Status = txtStatus.Text
                };

                entities.Services.Add(newService);
                entities.SaveChanges();
                gridServices.ItemsSource = entities.Services.ToList();
                MessageBox.Show("Сервисная работа успешно добавлена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditService_Click(object sender, RoutedEventArgs e)
        {
            if (gridServices.SelectedItem != null)
            {
                var selectedService = gridServices.SelectedItem as Services;
                selectedService.CarID = int.Parse(txtCarID1.Text);
                selectedService.ServiceDate = dpServiceDate.SelectedDate.Value;
                selectedService.Description = txtDescription.Text;
                selectedService.Cost = decimal.Parse(txtCost.Text);
                selectedService.Status = txtStatus.Text;

                entities.SaveChanges();
                gridServices.Items.Refresh();
                MessageBox.Show("Сервисная работа успешно изменена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите сервисную работу для изменения.");
            }
        }

        private void DeleteService_Click(object sender, RoutedEventArgs e)
        {
            if (gridServices.SelectedItem != null)
            {
                var selectedService = gridServices.SelectedItem as Services;
                entities.Services.Remove(selectedService);
                entities.SaveChanges();
                gridServices.ItemsSource = entities.Services.ToList();
                MessageBox.Show("Сервисная работа успешно удалена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите сервисную работу для удаления.");
            }
        }

        private void AddSupplier_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtSupplierName.Text))
                {
                    MessageBox.Show("Название поставщика");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtContactName.Text))
                {
                    MessageBox.Show("Введите ФИО поставщика");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtSupplierPhone.Text))
                {
                    MessageBox.Show("Введите телефон");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtSupplierAddress.Text))
                {
                    MessageBox.Show("Введите адрес");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtSupplierEmail.Text))
                {
                    MessageBox.Show("Введите email");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtSupplierName.Text) || string.IsNullOrWhiteSpace(txtContactName.Text) || string.IsNullOrWhiteSpace(txtSupplierPhone.Text) || string.IsNullOrWhiteSpace(txtSupplierAddress.Text) || string.IsNullOrWhiteSpace(txtSupplierEmail.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtSupplierPhone.Text))
                {
                    MessageBox.Show("Номер телефона должен содержать только цифры.");
                    return;
                }


                var newSupplier = new Suppliers
                {
                    Name = txtSupplierName.Text,
                    ContactName = txtContactName.Text,
                    Phone = txtSupplierPhone.Text,
                    Address = txtSupplierAddress.Text,
                    Email = txtSupplierEmail.Text
                };

                entities.Suppliers.Add(newSupplier);
                entities.SaveChanges();
                gridSuppliers.ItemsSource = entities.Suppliers.ToList();
                MessageBox.Show("Поставщик успешно добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditSupplier_Click(object sender, RoutedEventArgs e)
        {
            if (gridSuppliers.SelectedItem != null)
            {
                var selectedSupplier = gridSuppliers.SelectedItem as Suppliers;
                selectedSupplier.Name = txtSupplierName.Text;
                selectedSupplier.ContactName = txtContactName.Text;
                selectedSupplier.Phone = txtSupplierPhone.Text;
                selectedSupplier.Address = txtSupplierAddress.Text;
                selectedSupplier.Email = txtSupplierEmail.Text;

                entities.SaveChanges();
                gridSuppliers.Items.Refresh();
                MessageBox.Show("Поставщик успешно изменен.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите поставщика для изменения.");
            }
        }

        private void DeleteSupplier_Click(object sender, RoutedEventArgs e)
        {
            if (gridSuppliers.SelectedItem != null)
            {
                var selectedSupplier = gridSuppliers.SelectedItem as Suppliers;
                entities.Suppliers.Remove(selectedSupplier);
                entities.SaveChanges();
                gridSuppliers.ItemsSource = entities.Suppliers.ToList();
                MessageBox.Show("Поставщик успешно удален.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите поставщика для удаления.");
            }
        }

        private void AddPartSupplier_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtPartID.Text))
                {
                    MessageBox.Show("Введите id запчасти");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtSupplierID.Text))
                {
                    MessageBox.Show("Введите id поставщика");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPartSupplierPrice.Text))
                {
                    MessageBox.Show("Введите цену");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtDeliveryStatus.Text))
                {
                    MessageBox.Show("Введите статус доставки");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPartID.Text) || string.IsNullOrWhiteSpace(txtSupplierID.Text) || string.IsNullOrWhiteSpace(txtPartSupplierPrice.Text) || string.IsNullOrWhiteSpace(txtDeliveryStatus.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtPartID.Text))
                {
                    MessageBox.Show("ID запчасти должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtSupplierID.Text))
                {
                    MessageBox.Show("ID поставщика должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtPartSupplierPrice.Text))
                {
                    MessageBox.Show("Цена должна содержать только цифры.");
                    return;
                }

                var newPartSupplier = new PartSuppliers
                {
                    PartID = int.Parse(txtPartID.Text),
                    SupplierID = int.Parse(txtSupplierID.Text),
                    Price = decimal.Parse(txtPartSupplierPrice.Text),
                    DeliveryStatus = txtDeliveryStatus.Text
                };

                entities.PartSuppliers.Add(newPartSupplier);
                entities.SaveChanges();
                gridPartSuppliers.ItemsSource = entities.PartSuppliers.ToList();
                MessageBox.Show("Поставка запчастей успешно добавлена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditPartSupplier_Click(object sender, RoutedEventArgs e)
        {
            if (gridPartSuppliers.SelectedItem != null)
            {
                var selectedPartSupplier = gridPartSuppliers.SelectedItem as PartSuppliers;
                selectedPartSupplier.PartID = int.Parse(txtPartID.Text);
                selectedPartSupplier.SupplierID = int.Parse(txtSupplierID.Text);
                selectedPartSupplier.Price = decimal.Parse(txtPartSupplierPrice.Text);
                selectedPartSupplier.DeliveryStatus = txtDeliveryStatus.Text;

                entities.SaveChanges();
                gridPartSuppliers.Items.Refresh();
                MessageBox.Show("Поставка запчастей успешно изменена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите поставку запчастей для изменения.");
            }
        }

        private void DeletePartSupplier_Click(object sender, RoutedEventArgs e)
        {
            if (gridPartSuppliers.SelectedItem != null)
            {
                var selectedPartSupplier = gridPartSuppliers.SelectedItem as PartSuppliers;
                entities.PartSuppliers.Remove(selectedPartSupplier);
                entities.SaveChanges();
                gridPartSuppliers.ItemsSource = entities.PartSuppliers.ToList();
                MessageBox.Show("Поставка запчастей успешно удалена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите поставку запчастей для удаления.");
            }
        }

        private void AddWarehouse_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtWarehousePartID.Text))
                {
                    MessageBox.Show("Введите id запчасти");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtQuantity.Text))
                {
                    MessageBox.Show("Введите количество запчастей");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtLocation.Text))
                {
                    MessageBox.Show("Введите номер склада");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtWarehousePartID.Text) || string.IsNullOrWhiteSpace(txtQuantity.Text) || string.IsNullOrWhiteSpace(txtLocation.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtWarehousePartID.Text))
                {
                    MessageBox.Show("ID запчасти должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtQuantity.Text))
                {
                    MessageBox.Show("Количество запчастей должно содержать только цифры.");
                    return;
                }


                var newWarehouse = new Warehouse
                {
                    PartID = int.Parse(txtWarehousePartID.Text),
                    Quantity = int.Parse(txtQuantity.Text),
                    Location = txtLocation.Text
                };

                entities.Warehouse.Add(newWarehouse);
                entities.SaveChanges();
                gridWarehouse.ItemsSource = entities.Warehouse.ToList();
                MessageBox.Show("Запись на складе успешно добавлена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditWarehouse_Click(object sender, RoutedEventArgs e)
        {
            if (gridWarehouse.SelectedItem != null)
            {
                var selectedWarehouse = gridWarehouse.SelectedItem as Warehouse;
                selectedWarehouse.PartID = int.Parse(txtWarehousePartID.Text);
                selectedWarehouse.Quantity = int.Parse(txtQuantity.Text);
                selectedWarehouse.Location = txtLocation.Text;

                entities.SaveChanges();
                gridWarehouse.Items.Refresh();
                MessageBox.Show("Запись на складе успешно изменена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запись на складе для изменения.");
            }
        }

        private void DeleteWarehouse_Click(object sender, RoutedEventArgs e)
        {
            if (gridWarehouse.SelectedItem != null)
            {
                var selectedWarehouse = gridWarehouse.SelectedItem as Warehouse;
                entities.Warehouse.Remove(selectedWarehouse);
                entities.SaveChanges();
                gridWarehouse.ItemsSource = entities.Warehouse.ToList();
                MessageBox.Show("Запись на складе успешно удалена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запись на складе для удаления.");
            }
        }

        private void AddComplaint_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCustomerID1.Text))
                {
                    MessageBox.Show("Введите id клиента");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtComplaintDescription.Text))
                {
                    MessageBox.Show("Введите проблему");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtResolution.Text))
                {
                    MessageBox.Show("Введите гарантийное решение");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtComplaintStatus.Text))
                {
                    MessageBox.Show("Введите статус решения гарантийной проблемы");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtCustomerID1.Text) || string.IsNullOrWhiteSpace(txtComplaintDescription.Text) || string.IsNullOrWhiteSpace(txtResolution.Text) || string.IsNullOrWhiteSpace(txtComplaintStatus.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtCustomerID1.Text))
                {
                    MessageBox.Show("ID клиента должен содержать только цифры.");
                    return;
                }



                var newComplaint = new Complaints
                {
                    CustomerID = int.Parse(txtCustomerID1.Text),
                    Description = txtComplaintDescription.Text,
                    Resolution = txtResolution.Text,
                    Status = txtComplaintStatus.Text
                };

                entities.Complaints.Add(newComplaint);
                entities.SaveChanges();
                gridComplaints.ItemsSource = entities.Complaints.ToList();
                MessageBox.Show("Жалоба успешно добавлена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }


        private void EditComplaint_Click(object sender, RoutedEventArgs e)
        {
            if (gridComplaints.SelectedItem != null)
            {
                var selectedComplaint = gridComplaints.SelectedItem as Complaints;
                selectedComplaint.CustomerID = int.Parse(txtCustomerID1.Text);
                selectedComplaint.Description = txtComplaintDescription.Text;
                selectedComplaint.Resolution = txtResolution.Text;
                selectedComplaint.Status = txtComplaintStatus.Text;

                entities.SaveChanges();
                gridComplaints.Items.Refresh();
                MessageBox.Show("Жалоба успешно изменена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите жалобу для изменения.");
            }
        }

        private void DeleteComplaint_Click(object sender, RoutedEventArgs e)
        {
            if (gridComplaints.SelectedItem != null)
            {
                var selectedComplaint = gridComplaints.SelectedItem as Complaints;
                entities.Complaints.Remove(selectedComplaint);
                entities.SaveChanges();
                gridComplaints.ItemsSource = entities.Complaints.ToList();
                MessageBox.Show("Жалоба успешно удалена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите жалобу для удаления.");
            }
        }






    
      

    


        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            TabItem selectedTab = (sender as TabControl)?.SelectedItem as TabItem;
            switch (selectedTab?.Header)
            {
               
                case "Cars":
                    gridCars.ItemsSource = entities.Cars.ToList();
                    break;
               
                case "Services":
                    gridServices.ItemsSource = entities.Services.ToList();
                    break;
                case "Parts":
                    gridParts.ItemsSource = entities.Parts.ToList();
                    break;
                case "Suppliers":
                    gridSuppliers.ItemsSource = entities.Suppliers.ToList();
                    break;
                case "PartSuppliers":
                    gridPartSuppliers.ItemsSource = entities.PartSuppliers.ToList();
                    break;
                case "Warehouse":
                    gridWarehouse.ItemsSource = entities.Warehouse.ToList();
                    break;
                case "Complaints":
                    gridComplaints.ItemsSource = entities.Complaints.ToList();
                    break;
             
            }
        }



        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid dataGrid = (DataGrid)sender;

            if (dataGrid.SelectedItem != null)
            {
                // Получаем выбранный элемент из DataGrid'а
                dynamic selectedItem = dataGrid.SelectedItem;

                // Обновляем поля ввода на основе выбранного элемента
                switch (dataGrid.Name)
                {
                 
                    case "gridCars":
                        txtMake.Text = selectedItem.Make;
                        txtModel.Text = selectedItem.Model;
                        txtYear.Text = selectedItem.Year.ToString();
                        txtPrice.Text = selectedItem.Price.ToString();
                        txtColor.Text = selectedItem.Color;
                        break;
                  
                    case "gridServices":
                        txtCarID1.Text = selectedItem.CarID.ToString();
                        dpServiceDate.SelectedDate = selectedItem.ServiceDate;
                        txtDescription.Text = selectedItem.Description;
                        txtCost.Text = selectedItem.Cost.ToString();
                        txtStatus.Text = selectedItem.Status;
                        break;
                    case "gridParts":
                        txtPartName.Text = selectedItem.Name;
                        txtPartDescription.Text = selectedItem.Description;
                        txtPartPrice.Text = selectedItem.Price.ToString();
                        txtPartCategory.Text = selectedItem.Category;
                        break;
                    case "gridSuppliers":
                        txtSupplierName.Text = selectedItem.Name;
                        txtContactName.Text = selectedItem.ContactName;
                        txtSupplierPhone.Text = selectedItem.Phone;
                        txtSupplierAddress.Text = selectedItem.Address;
                        txtSupplierEmail.Text = selectedItem.Email;
                        break;
                    case "gridPartSuppliers":
                        txtPartID.Text = selectedItem.PartID.ToString();
                        txtSupplierID.Text = selectedItem.SupplierID.ToString();
                        txtPartSupplierPrice.Text = selectedItem.Price.ToString();
                        txtDeliveryStatus.Text = selectedItem.DeliveryStatus;
                        break;
                    case "gridWarehouse":
                        txtWarehousePartID.Text = selectedItem.PartID.ToString();
                        txtQuantity.Text = selectedItem.Quantity.ToString();
                        txtLocation.Text = selectedItem.Location;
                        break;
                    case "gridComplaints":
                        txtCustomerID1.Text = selectedItem.CustomerID.ToString();
                        txtComplaintDescription.Text = selectedItem.Description;
                        txtResolution.Text = selectedItem.Resolution;
                        txtComplaintStatus.Text = selectedItem.Status;
                        break;
                    
                }

            }
        }
    }
}
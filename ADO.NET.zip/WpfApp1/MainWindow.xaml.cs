﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Data.Entity;


namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;

            using (var context = new DbContext("storeAutoEntities"))
            {
                var user = context.Database.SqlQuery<Employees>("SELECT * FROM Employees WHERE Login = @p0 AND Password = @p1", username, password).FirstOrDefault();

                if (user != null)
                {
                    switch (user.Position)
                    {
                        case "Менеджер по продажам":
                            GlavnayaFrame.Content = new ManagerPage();
                            break;
                        case "Механик":
                            GlavnayaFrame.Content = new MechanicPage();
                            break;
                        case "Директор":
                            GlavnayaFrame.Content = new AdminPage();
                            break;
                        case "Бухгалтер":
                            GlavnayaFrame.Content = new AccountantsPage();
                            break;
                        case "Менеджер по маркетингу":
                            GlavnayaFrame.Content = new MarketingManager();
                            break;
                        default:
                            MessageBox.Show("У вас нет доступа к этой роли.");
                            break;
                    }
                }
                else
                {
                    MessageBox.Show("Неверное имя пользователя или пароль.");
                }
            }
        }

    }
}
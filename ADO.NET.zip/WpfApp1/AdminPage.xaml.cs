﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    public partial class AdminPage : Page
    {
        private storeAutoEntities entities = new storeAutoEntities();

        public AdminPage()
        {
            InitializeComponent();

            InitializeDataGrids();
        }

        private void InitializeDataGrids()
        {
            gridCustomers.ItemsSource = entities.Customers.ToList();
            gridCars.ItemsSource = entities.Cars.ToList();
            gridSales.ItemsSource = entities.Sales.ToList();
            gridEmployees.ItemsSource = entities.Employees.ToList();
            gridManufacturers.ItemsSource = entities.Manufacturers.ToList();
            gridServices.ItemsSource = entities.Services.ToList();
            gridParts.ItemsSource = entities.Parts.ToList();
            gridSuppliers.ItemsSource = entities.Suppliers.ToList();
            gridPartSuppliers.ItemsSource = entities.PartSuppliers.ToList();
            gridWarehouse.ItemsSource = entities.Warehouse.ToList();
            gridComplaints.ItemsSource = entities.Complaints.ToList();
            gridInsurances.ItemsSource = entities.Insurances.ToList();
            gridLoans.ItemsSource = entities.Loans.ToList();
            gridManufacturerContracts.ItemsSource = entities.ManufacturerContracts.ToList();


            gridCustomers.SelectionChanged += DataGrid_SelectionChanged;
            gridCars.SelectionChanged += DataGrid_SelectionChanged;
            gridSales.SelectionChanged += DataGrid_SelectionChanged;
            gridEmployees.SelectionChanged += DataGrid_SelectionChanged;
            gridManufacturers.SelectionChanged += DataGrid_SelectionChanged;
            gridServices.SelectionChanged += DataGrid_SelectionChanged;
            gridParts.SelectionChanged += DataGrid_SelectionChanged;
            gridSuppliers.SelectionChanged += DataGrid_SelectionChanged;
            gridPartSuppliers.SelectionChanged += DataGrid_SelectionChanged;
            gridWarehouse.SelectionChanged += DataGrid_SelectionChanged;
            gridComplaints.SelectionChanged += DataGrid_SelectionChanged;
            gridInsurances.SelectionChanged += DataGrid_SelectionChanged;
            gridLoans.SelectionChanged += DataGrid_SelectionChanged;
            gridManufacturerContracts.SelectionChanged += DataGrid_SelectionChanged;
            this.MouseDown += Page_MouseDown;

        }


        private void Page_MouseDown(object sender, MouseButtonEventArgs e)
        {

            ClearInputFields();
        }

        private void ClearInputFields()
        {
           
            txtCustomerName.Text = string.Empty;
            txtPhone.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtMake.Text = string.Empty;
            txtModel.Text = string.Empty;
            txtYear.Text = string.Empty;
            txtPrice.Text = string.Empty;
            txtColor.Text = string.Empty;
            gridCustomers.SelectedItem = null;
            gridCars.SelectedItem = null;
            dpSaleDate.SelectedDate = null;
            dpHireDate.SelectedDate = null;
            txtManufacturerID.Text = string.Empty;
            dpStartDate2.SelectedDate = null;
            dpEndDate2.SelectedDate = null;
            txtTerms.Text = string.Empty;
            txtCustomerID3.Text = string.Empty;
            txtLoanAmount.Text = string.Empty;
            Duration.Text = string.Empty;
            BankName.Text = string.Empty;
            txtInterestRate.Text = string.Empty;
            txtCustomerID2.Text = string.Empty;
            txtInsuranceType.Text = string.Empty;
            dpStartDate.Text = string.Empty;
            dpEndDate.Text = string.Empty;
            txtPremium.Text = string.Empty;
            txtEmployeeName.Text = string.Empty;
            txtPosition.Text = string.Empty;
            txtSalary.Text = string.Empty;
            dpHireDate.SelectedDate = null;
            txtDepartment.Text = string.Empty;
            txtLogin.Text = string.Empty;
            txtPassword.Text = string.Empty;
            txtCarID1.Text = string.Empty;
            dpServiceDate.SelectedDate = null;
            txtDescription.Text = string.Empty;
            txtCost.Text = string.Empty;
            txtStatus.Text = string.Empty;
            gridServices.SelectedItem = null;
            txtPartName.Text = string.Empty;
            txtPartDescription.Text = string.Empty;
            txtPartPrice.Text = string.Empty;
            txtPartCategory.Text = string.Empty;
            gridParts.SelectedItem = null;
            txtSupplierName.Text = string.Empty;
            txtContactName.Text = string.Empty;
            txtSupplierPhone.Text = string.Empty;
            txtSupplierAddress.Text = string.Empty;
            txtSupplierEmail.Text = string.Empty;
            gridSuppliers.SelectedItem = null;
            txtPartID.Text = string.Empty;
            txtSupplierID.Text = string.Empty;
            txtPartSupplierPrice.Text = string.Empty;
            txtDeliveryStatus.Text = string.Empty;
            gridPartSuppliers.SelectedItem = null;
            txtWarehousePartID.Text = string.Empty;
            txtQuantity.Text = string.Empty;
            txtLocation.Text = string.Empty;
            gridWarehouse.SelectedItem = null;
            txtCustomerID1.Text = string.Empty;
            txtComplaintDescription.Text = string.Empty;
            txtResolution.Text = string.Empty;
            txtComplaintStatus.Text = string.Empty;
            gridComplaints.SelectedItem = null;
            txtCustomerID.Text = string.Empty;
            txtCarID.Text = string.Empty;
            dpSaleDate.SelectedDate = null;
            txtSalePrice.Text = string.Empty;
            txtNote.Text = string.Empty;
            gridSales.SelectedItem = null;
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
           
            MainWindow mainWindow = new MainWindow();

            Application.Current.MainWindow = mainWindow;

            NavigationService?.Navigate(null); 
        }


        private void AddCustomer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCustomerName.Text))
                {
                    MessageBox.Show("Введите имя клиента.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPhone.Text))
                {
                    MessageBox.Show("Введите телефон клиента.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtEmail.Text))
                {
                    MessageBox.Show("Введите почту клиента.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtAddress.Text))
                {
                    MessageBox.Show("Введите адрес клиента.");
                    return;
                }
            
                    if (string.IsNullOrWhiteSpace(txtCustomerName.Name) || string.IsNullOrWhiteSpace(txtPhone.Text) || string.IsNullOrWhiteSpace(txtEmail.Text) || string.IsNullOrWhiteSpace(txtAddress.Text))
                    {
                        MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                        return;
                    }

                    if (!IsPhoneNumber(txtPhone.Text))
                    {
                        MessageBox.Show("Номер телефона должен содержать только цифры.");
                        return;
                    }

             
               
                var newCustomer = new Customers
                {
                    Name = txtCustomerName.Text,
                    Phone = txtPhone.Text,
                    Email = txtEmail.Text,
                    Address = txtAddress.Text
                };

                entities.Customers.Add(newCustomer);
                entities.SaveChanges();
                gridCustomers.ItemsSource = entities.Customers.ToList();
                MessageBox.Show("Клиент успешно добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

       

        private bool IsPhoneNumber(string input)
        {
            foreach (char c in input)
            {
                if (!char.IsDigit(c))
                {
                    return false;
                }
            }
            return true;
        }


        private void EditCustomer_Click(object sender, RoutedEventArgs e)
        {
            if (gridCustomers.SelectedItem != null)
            {
                var selectedCustomer = gridCustomers.SelectedItem as Customers;
                selectedCustomer.Name = txtCustomerName.Text;
                selectedCustomer.Phone = txtPhone.Text;
                selectedCustomer.Email = txtEmail.Text;
                selectedCustomer.Address = txtAddress.Text;

                entities.SaveChanges();
                gridCustomers.Items.Refresh();
                MessageBox.Show("Клиент успешно изменен.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите клиента для изменения.");
            }
        }

        private void DeleteCustomer_Click(object sender, RoutedEventArgs e)
        {
            if (gridCustomers.SelectedItem != null)
            {
                var selectedCustomer = gridCustomers.SelectedItem as Customers;
                entities.Customers.Remove(selectedCustomer);
                entities.SaveChanges();
                gridCustomers.ItemsSource = entities.Customers.ToList();
                MessageBox.Show("Клиент успешно удален.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите клиента для удаления.");
            }
        }

        private void AddCar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtMake.Text))
                {
                    MessageBox.Show("Введите марку.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtModel.Text))
                {
                    MessageBox.Show("Введите модель.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtYear.Text))
                {
                    MessageBox.Show("Введите год выпуска.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPrice.Text))
                {
                    MessageBox.Show("Введите цену.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtColor.Text))
                {
                    MessageBox.Show("Введите цвет.");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtMake.Text) || string.IsNullOrWhiteSpace(txtModel.Text) || string.IsNullOrWhiteSpace(txtYear.Text) || string.IsNullOrWhiteSpace(txtPrice.Text) || string.IsNullOrWhiteSpace(txtColor.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtYear.Text))
                {
                    MessageBox.Show("Год выпуска должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtPrice.Text))
                {
                    MessageBox.Show("Цена должна содержать только цифры.");
                    return;
                }


                var newCar = new Cars
                {
                    Make = txtMake.Text,
                    Model = txtModel.Text,
                    Year = int.Parse(txtYear.Text),
                    Price = decimal.Parse(txtPrice.Text),
                    Color = txtColor.Text
                };

                entities.Cars.Add(newCar);
                entities.SaveChanges();
                gridCars.ItemsSource = entities.Cars.ToList();
                MessageBox.Show("Автомобиль успешно добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditCar_Click(object sender, RoutedEventArgs e)
        {
            if (gridCars.SelectedItem != null)
            {
                var selectedCar = gridCars.SelectedItem as Cars;
                selectedCar.Make = txtMake.Text;
                selectedCar.Model = txtModel.Text;
                selectedCar.Year = int.Parse(txtYear.Text);
                selectedCar.Price = decimal.Parse(txtPrice.Text);
                selectedCar.Color = txtColor.Text;

                entities.SaveChanges();
                gridCars.Items.Refresh();
                MessageBox.Show("Автомобиль успешно изменен.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите автомобиль для изменения.");
            }
        }

        private void DeleteCar_Click(object sender, RoutedEventArgs e)
        {
            if (gridCars.SelectedItem != null)
            {
                var selectedCar = gridCars.SelectedItem as Cars;
                entities.Cars.Remove(selectedCar);
                entities.SaveChanges();
                gridCars.ItemsSource = entities.Cars.ToList();
                MessageBox.Show("Автомобиль успешно удален.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите автомобиль для удаления.");
            }
        }

        private void AddSale_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCustomerID.Text))
                {
                    MessageBox.Show("Введите Id клиента.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtCarID.Text))
                {
                    MessageBox.Show("Введите id авто.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(dpSaleDate.Text))
                {
                    MessageBox.Show("Введите дату");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtSalePrice.Text))
                {
                    MessageBox.Show("Введите % с продажи");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtNote.Text))
                {
                    MessageBox.Show("Введите условия проджажи");
                    return;
                }

                  if (string.IsNullOrWhiteSpace(txtCustomerID.Text) || string.IsNullOrWhiteSpace(txtCarID.Text) || string.IsNullOrWhiteSpace(dpSaleDate.Text) || string.IsNullOrWhiteSpace(txtSalePrice.Text) || string.IsNullOrWhiteSpace(txtNote.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtCustomerID.Text))
                {
                    MessageBox.Show("ID клиента должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtCarID.Text))
                {
                    MessageBox.Show("ID авто должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtSalePrice.Text))
                {
                    MessageBox.Show("Цена должна содержать только цифры.");
                    return;
                }

                var newSale = new Sales
                {
                    CustomerID = int.Parse(txtCustomerID.Text),
                    CarID = int.Parse(txtCarID.Text),
                    SaleDate = dpSaleDate.SelectedDate.Value,
                    SalePrice = decimal.Parse(txtSalePrice.Text),
                    Note = txtNote.Text
                };

                entities.Sales.Add(newSale);
                entities.SaveChanges();
                gridSales.ItemsSource = entities.Sales.ToList();
                MessageBox.Show("Продажа успешно добавлена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditSale_Click(object sender, RoutedEventArgs e)
        {
            if (gridSales.SelectedItem != null)
            {
                var selectedSale = gridSales.SelectedItem as Sales;
                selectedSale.CustomerID = int.Parse(txtCustomerID.Text);
                selectedSale.CarID = int.Parse(txtCarID.Text);
                selectedSale.SaleDate = dpSaleDate.SelectedDate.Value;
                selectedSale.SalePrice = decimal.Parse(txtSalePrice.Text);
                selectedSale.Note = txtNote.Text;

                entities.SaveChanges();
                gridSales.Items.Refresh();
                MessageBox.Show("Продажа успешно изменена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите продажу для изменения.");
            }
        }

        private void DeleteSale_Click(object sender, RoutedEventArgs e)
        {
            if (gridSales.SelectedItem != null)
            {
                var selectedSale = gridSales.SelectedItem as Sales;
                entities.Sales.Remove(selectedSale);
                entities.SaveChanges();
                gridSales.ItemsSource = entities.Sales.ToList();
                MessageBox.Show("Продажа успешно удалена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите продажу для удаления.");
            }
        }

        private void AddEmployee_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtEmployeeName.Text))
                {
                    MessageBox.Show("Введите имя работника.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPosition.Text))
                {
                    MessageBox.Show("Введите должность работника.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(dpHireDate.Text))
                {
                    MessageBox.Show("Выберите дату");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPosition.Text))
                {
                    MessageBox.Show("Выберите должность");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtSalary.Text))
                {
                    MessageBox.Show("Введите ЗП");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtDepartment.Text))
                {
                    MessageBox.Show("Выберите отдел");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtLogin.Text))
                {
                    MessageBox.Show("Введите логин работника");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPassword.Text))
                {
                    MessageBox.Show("Введите пароль работника");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtEmployeeName.Text) || string.IsNullOrWhiteSpace(txtPosition.Text) || string.IsNullOrWhiteSpace(txtSalary.Text) || string.IsNullOrWhiteSpace(dpHireDate.Text) || string.IsNullOrWhiteSpace(txtDepartment.Text) || string.IsNullOrWhiteSpace(txtLogin.Text) || string.IsNullOrWhiteSpace(txtPassword.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtSalary.Text))
                {
                    MessageBox.Show("Зарплата должна содержать только цифры.");
                    return;
                }
                var existingEmployee = entities.Employees.FirstOrDefault(emp => emp.Login == txtLogin.Text);
                if (existingEmployee != null)
                {
                    MessageBox.Show("Сотрудник с таким логином уже существует.");
                    return;
                }

                var newEmployee = new Employees
                {
                    Name = txtEmployeeName.Text,
                    Position = txtPosition.Text,
                    Salary = decimal.Parse(txtSalary.Text),
                    HireDate = dpHireDate.SelectedDate.Value,
                    Department = txtDepartment.Text,
                    Login = txtLogin.Text,
                    Password = txtPassword.Text
                };

                entities.Employees.Add(newEmployee);
                entities.SaveChanges();
                gridEmployees.ItemsSource = entities.Employees.ToList();
                MessageBox.Show("Сотрудник успешно добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditEmployee_Click(object sender, RoutedEventArgs e)
        {
            if (gridEmployees.SelectedItem != null)
            {
                var selectedEmployee = gridEmployees.SelectedItem as Employees;
                selectedEmployee.Name = txtEmployeeName.Text;
                selectedEmployee.Position = txtPosition.Text;
                selectedEmployee.Salary = decimal.Parse(txtSalary.Text);
                selectedEmployee.HireDate = dpHireDate.SelectedDate.Value;
                selectedEmployee.Department = txtDepartment.Text;
                selectedEmployee.Login = txtLogin.Text;
                selectedEmployee.Password = txtPassword.Text;

                entities.SaveChanges();
                gridEmployees.Items.Refresh();
                MessageBox.Show("Сотрудник успешно изменен.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите сотрудника для изменения.");
            }
        }

        private void DeleteEmployee_Click(object sender, RoutedEventArgs e)
        {
            if (gridEmployees.SelectedItem != null)
            {
                var selectedEmployee = gridEmployees.SelectedItem as Employees;
                entities.Employees.Remove(selectedEmployee);
                entities.SaveChanges();
                gridEmployees.ItemsSource = entities.Employees.ToList();
                MessageBox.Show("Сотрудник успешно удален.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите сотрудника для удаления.");
            }
        }
        private void AddManufacturer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtManufacturerName.Text))
                {
                    MessageBox.Show("Введите имя марки.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtCountry.Text))
                {
                    MessageBox.Show("Введите страну.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtWebsite.Text))
                {
                    MessageBox.Show("Введите сайт");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtManufacturerName.Text) || string.IsNullOrWhiteSpace(txtCountry.Text) || string.IsNullOrWhiteSpace(txtWebsite.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }


                var newManufacturer = new Manufacturers
                {
                    Name = txtManufacturerName.Text,
                    Country = txtCountry.Text,
                    Website = txtWebsite.Text
                };

                entities.Manufacturers.Add(newManufacturer);
                entities.SaveChanges();
                gridManufacturers.ItemsSource = entities.Manufacturers.ToList();
                MessageBox.Show("Производитель успешно добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditManufacturer_Click(object sender, RoutedEventArgs e)
        {
            if (gridManufacturers.SelectedItem != null)
            {
                var selectedManufacturer = gridManufacturers.SelectedItem as Manufacturers;
                selectedManufacturer.Name = txtManufacturerName.Text;
                selectedManufacturer.Country = txtCountry.Text;
                selectedManufacturer.Website = txtWebsite.Text;

                entities.SaveChanges();
                gridManufacturers.Items.Refresh();
                MessageBox.Show("Производитель успешно изменен.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите производителя для изменения.");
            }
        }

        private void DeleteManufacturer_Click(object sender, RoutedEventArgs e)
        {
            if (gridManufacturers.SelectedItem != null)
            {
                var selectedManufacturer = gridManufacturers.SelectedItem as Manufacturers;
                entities.Manufacturers.Remove(selectedManufacturer);
                entities.SaveChanges();
                gridManufacturers.ItemsSource = entities.Manufacturers.ToList();
                MessageBox.Show("Производитель успешно удален.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите производителя для удаления.");
            }
        }



        private void AddPart_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtPartName.Text))
                {
                    MessageBox.Show("Введите категорию запчасти.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPartDescription.Text))
                {
                    MessageBox.Show("Введите название запчасти.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPartPrice.Text))
                {
                    MessageBox.Show("Введите цену");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPartCategory.Text))
                {
                    MessageBox.Show("Введите категорию");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtPartName.Text) || string.IsNullOrWhiteSpace(txtPartDescription.Text) || string.IsNullOrWhiteSpace(txtPartPrice.Text) || string.IsNullOrWhiteSpace(txtPartCategory.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtPartPrice.Text))
                {
                    MessageBox.Show("Цена должна содержать только цифры.");
                    return;
                }

                var newPart = new Parts
                {
                    Name = txtPartName.Text,
                    Description = txtPartDescription.Text,
                    Price = decimal.Parse(txtPartPrice.Text),
                    Category = txtPartCategory.Text
                };

                entities.Parts.Add(newPart);
                entities.SaveChanges();
                gridParts.ItemsSource = entities.Parts.ToList();
                MessageBox.Show("Запчасть успешно добавлена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditPart_Click(object sender, RoutedEventArgs e)
        {
            if (gridParts.SelectedItem != null)
            {
                var selectedPart = gridParts.SelectedItem as Parts;
                selectedPart.Name = txtPartName.Text;
                selectedPart.Description = txtPartDescription.Text;
                selectedPart.Price = decimal.Parse(txtPartPrice.Text);
                selectedPart.Category = txtPartCategory.Text;

                entities.SaveChanges();
                gridParts.Items.Refresh();
                MessageBox.Show("Запчасть успешно изменена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запчасть для изменения.");
            }
        }

        private void DeletePart_Click(object sender, RoutedEventArgs e)
        {
            if (gridParts.SelectedItem != null)
            {
                var selectedPart = gridParts.SelectedItem as Parts;
                entities.Parts.Remove(selectedPart);
                entities.SaveChanges();
                gridParts.ItemsSource = entities.Parts.ToList();
                MessageBox.Show("Запчасть успешно удалена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запчасть для удаления.");
            }
        }


         private void AddService_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCarID1.Text))
                {
                    MessageBox.Show("Введите id авто.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(dpServiceDate.Text))
                {
                    MessageBox.Show("Выберите дату");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtDescription.Text))
                {
                    MessageBox.Show("Введите услугу");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtCost.Text))
                {
                    MessageBox.Show("Введите цену");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtStatus.Text))
                {
                    MessageBox.Show("Введите статус");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtCarID1.Text) || string.IsNullOrWhiteSpace(dpServiceDate.Text) || string.IsNullOrWhiteSpace(txtDescription.Text) || string.IsNullOrWhiteSpace(txtCost.Text) || string.IsNullOrWhiteSpace(txtStatus.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtCarID1.Text))
                {
                    MessageBox.Show("ID авто должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtCost.Text))
                {
                    MessageBox.Show("Цена должна содержать только цифры.");
                    return;
                }

                var newService = new Services
                {
                    CarID = int.Parse(txtCarID1.Text),
                    ServiceDate = dpServiceDate.SelectedDate.Value,
                    Description = txtDescription.Text,
                    Cost = decimal.Parse(txtCost.Text),
                    Status = txtStatus.Text
                };

                entities.Services.Add(newService);
                entities.SaveChanges();
                gridServices.ItemsSource = entities.Services.ToList();
                MessageBox.Show("Сервисная работа успешно добавлена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditService_Click(object sender, RoutedEventArgs e)
        {
            if (gridServices.SelectedItem != null)
            {
                var selectedService = gridServices.SelectedItem as Services;
                selectedService.CarID = int.Parse(txtCarID1.Text);
                selectedService.ServiceDate = dpServiceDate.SelectedDate.Value;
                selectedService.Description = txtDescription.Text;
                selectedService.Cost = decimal.Parse(txtCost.Text);
                selectedService.Status = txtStatus.Text;

                entities.SaveChanges();
                gridServices.Items.Refresh();
                MessageBox.Show("Сервисная работа успешно изменена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите сервисную работу для изменения.");
            }
        }

        private void DeleteService_Click(object sender, RoutedEventArgs e)
        {
            if (gridServices.SelectedItem != null)
            {
                var selectedService = gridServices.SelectedItem as Services;
                entities.Services.Remove(selectedService);
                entities.SaveChanges();
                gridServices.ItemsSource = entities.Services.ToList();
                MessageBox.Show("Сервисная работа успешно удалена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите сервисную работу для удаления.");
            }
        }

        private void AddSupplier_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtSupplierName.Text))
                {
                    MessageBox.Show("Название поставщика");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtContactName.Text))
                {
                    MessageBox.Show("Введите ФИО поставщика");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtSupplierPhone.Text))
                {
                    MessageBox.Show("Введите телефон");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtSupplierAddress.Text))
                {
                    MessageBox.Show("Введите адрес");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtSupplierEmail.Text))
                {
                    MessageBox.Show("Введите email");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtSupplierName.Text) || string.IsNullOrWhiteSpace(txtContactName.Text) || string.IsNullOrWhiteSpace(txtSupplierPhone.Text) || string.IsNullOrWhiteSpace(txtSupplierAddress.Text) || string.IsNullOrWhiteSpace(txtSupplierEmail.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtSupplierPhone.Text))
                {
                    MessageBox.Show("Номер телефона должен содержать только цифры.");
                    return;
                }
               

                var newSupplier = new Suppliers
                {
                    Name = txtSupplierName.Text,
                    ContactName = txtContactName.Text,
                    Phone = txtSupplierPhone.Text,
                    Address = txtSupplierAddress.Text,
                    Email = txtSupplierEmail.Text
                };

                entities.Suppliers.Add(newSupplier);
                entities.SaveChanges();
                gridSuppliers.ItemsSource = entities.Suppliers.ToList();
                MessageBox.Show("Поставщик успешно добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditSupplier_Click(object sender, RoutedEventArgs e)
        {
            if (gridSuppliers.SelectedItem != null)
            {
                var selectedSupplier = gridSuppliers.SelectedItem as Suppliers;
                selectedSupplier.Name = txtSupplierName.Text;
                selectedSupplier.ContactName = txtContactName.Text;
                selectedSupplier.Phone = txtSupplierPhone.Text;
                selectedSupplier.Address = txtSupplierAddress.Text;
                selectedSupplier.Email = txtSupplierEmail.Text;

                entities.SaveChanges();
                gridSuppliers.Items.Refresh();
                MessageBox.Show("Поставщик успешно изменен.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите поставщика для изменения.");
            }
        }

        private void DeleteSupplier_Click(object sender, RoutedEventArgs e)
        {
            if (gridSuppliers.SelectedItem != null)
            {
                var selectedSupplier = gridSuppliers.SelectedItem as Suppliers;
                entities.Suppliers.Remove(selectedSupplier);
                entities.SaveChanges();
                gridSuppliers.ItemsSource = entities.Suppliers.ToList();
                MessageBox.Show("Поставщик успешно удален.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите поставщика для удаления.");
            }
        }

        private void AddPartSupplier_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtPartID.Text))
                {
                    MessageBox.Show("Введите id запчасти");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtSupplierID.Text))
                {
                    MessageBox.Show("Введите id поставщика");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPartSupplierPrice.Text))
                {
                    MessageBox.Show("Введите цену");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtDeliveryStatus.Text))
                {
                    MessageBox.Show("Введите статус доставки");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPartID.Text) || string.IsNullOrWhiteSpace(txtSupplierID.Text) || string.IsNullOrWhiteSpace(txtPartSupplierPrice.Text) || string.IsNullOrWhiteSpace(txtDeliveryStatus.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtPartID.Text))
                {
                    MessageBox.Show("ID запчасти должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtSupplierID.Text))
                {
                    MessageBox.Show("ID поставщика должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtPartSupplierPrice.Text))
                {
                    MessageBox.Show("Цена должна содержать только цифры.");
                    return;
                }

                var newPartSupplier = new PartSuppliers
                {
                    PartID = int.Parse(txtPartID.Text),
                    SupplierID = int.Parse(txtSupplierID.Text),
                    Price = decimal.Parse(txtPartSupplierPrice.Text),
                    DeliveryStatus = txtDeliveryStatus.Text
                };

                entities.PartSuppliers.Add(newPartSupplier);
                entities.SaveChanges();
                gridPartSuppliers.ItemsSource = entities.PartSuppliers.ToList();
                MessageBox.Show("Поставка запчастей успешно добавлена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditPartSupplier_Click(object sender, RoutedEventArgs e)
        {
            if (gridPartSuppliers.SelectedItem != null)
            {
                var selectedPartSupplier = gridPartSuppliers.SelectedItem as PartSuppliers;
                selectedPartSupplier.PartID = int.Parse(txtPartID.Text);
                selectedPartSupplier.SupplierID = int.Parse(txtSupplierID.Text);
                selectedPartSupplier.Price = decimal.Parse(txtPartSupplierPrice.Text);
                selectedPartSupplier.DeliveryStatus = txtDeliveryStatus.Text;

                entities.SaveChanges();
                gridPartSuppliers.Items.Refresh();
                MessageBox.Show("Поставка запчастей успешно изменена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите поставку запчастей для изменения.");
            }
        }

        private void DeletePartSupplier_Click(object sender, RoutedEventArgs e)
        {
            if (gridPartSuppliers.SelectedItem != null)
            {
                var selectedPartSupplier = gridPartSuppliers.SelectedItem as PartSuppliers;
                entities.PartSuppliers.Remove(selectedPartSupplier);
                entities.SaveChanges();
                gridPartSuppliers.ItemsSource = entities.PartSuppliers.ToList();
                MessageBox.Show("Поставка запчастей успешно удалена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите поставку запчастей для удаления.");
            }
        }

        private void AddWarehouse_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtWarehousePartID.Text))
                {
                    MessageBox.Show("Введите id запчасти");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtQuantity.Text))
                {
                    MessageBox.Show("Введите количество запчастей");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtLocation.Text))
                {
                    MessageBox.Show("Введите номер склада");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtWarehousePartID.Text) || string.IsNullOrWhiteSpace(txtQuantity.Text) || string.IsNullOrWhiteSpace(txtLocation.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtWarehousePartID.Text))
                {
                    MessageBox.Show("ID запчасти должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtQuantity.Text))
                {
                    MessageBox.Show("Количество запчастей должно содержать только цифры.");
                    return;
                }


                var newWarehouse = new Warehouse
                {
                    PartID = int.Parse(txtWarehousePartID.Text),
                    Quantity = int.Parse(txtQuantity.Text),
                    Location = txtLocation.Text
                };

                entities.Warehouse.Add(newWarehouse);
                entities.SaveChanges();
                gridWarehouse.ItemsSource = entities.Warehouse.ToList();
                MessageBox.Show("Запись на складе успешно добавлена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditWarehouse_Click(object sender, RoutedEventArgs e)
        {
            if (gridWarehouse.SelectedItem != null)
            {
                var selectedWarehouse = gridWarehouse.SelectedItem as Warehouse;
                selectedWarehouse.PartID = int.Parse(txtWarehousePartID.Text);
                selectedWarehouse.Quantity = int.Parse(txtQuantity.Text);
                selectedWarehouse.Location = txtLocation.Text;

                entities.SaveChanges();
                gridWarehouse.Items.Refresh();
                MessageBox.Show("Запись на складе успешно изменена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запись на складе для изменения.");
            }
        }

        private void DeleteWarehouse_Click(object sender, RoutedEventArgs e)
        {
            if (gridWarehouse.SelectedItem != null)
            {
                var selectedWarehouse = gridWarehouse.SelectedItem as Warehouse;
                entities.Warehouse.Remove(selectedWarehouse);
                entities.SaveChanges();
                gridWarehouse.ItemsSource = entities.Warehouse.ToList();
                MessageBox.Show("Запись на складе успешно удалена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запись на складе для удаления.");
            }
        }

        private void AddComplaint_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCustomerID1.Text))
                {
                    MessageBox.Show("Введите id клиента");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtComplaintDescription.Text))
                {
                    MessageBox.Show("Введите проблему");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtResolution.Text))
                {
                    MessageBox.Show("Введите гарантийное решение");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtComplaintStatus.Text))
                {
                    MessageBox.Show("Введите статус решения гарантийной проблемы");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtCustomerID1.Text) || string.IsNullOrWhiteSpace(txtComplaintDescription.Text) || string.IsNullOrWhiteSpace(txtResolution.Text) || string.IsNullOrWhiteSpace(txtComplaintStatus.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtCustomerID1.Text))
                {
                    MessageBox.Show("ID клиента должен содержать только цифры.");
                    return;
                }
               


                var newComplaint = new Complaints
                {
                    CustomerID = int.Parse(txtCustomerID1.Text),
                    Description = txtComplaintDescription.Text,
                    Resolution = txtResolution.Text,
                    Status = txtComplaintStatus.Text
                };

                entities.Complaints.Add(newComplaint);
                entities.SaveChanges();
                gridComplaints.ItemsSource = entities.Complaints.ToList();
                MessageBox.Show("Жалоба успешно добавлена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditComplaint_Click(object sender, RoutedEventArgs e)
        {
            if (gridComplaints.SelectedItem != null)
            {
                var selectedComplaint = gridComplaints.SelectedItem as Complaints;
                selectedComplaint.CustomerID = int.Parse(txtCustomerID1.Text);
                selectedComplaint.Description = txtComplaintDescription.Text;
                selectedComplaint.Resolution = txtResolution.Text;
                selectedComplaint.Status = txtComplaintStatus.Text;

                entities.SaveChanges();
                gridComplaints.Items.Refresh();
                MessageBox.Show("Жалоба успешно изменена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите жалобу для изменения.");
            }
        }

        private void DeleteComplaint_Click(object sender, RoutedEventArgs e)
        {
            if (gridComplaints.SelectedItem != null)
            {
                var selectedComplaint = gridComplaints.SelectedItem as Complaints;
                entities.Complaints.Remove(selectedComplaint);
                entities.SaveChanges();
                gridComplaints.ItemsSource = entities.Complaints.ToList();
                MessageBox.Show("Жалоба успешно удалена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите жалобу для удаления.");
            }
        }






    
      

        private void AddManufacturerContract_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtManufacturerID.Text))
                {
                    MessageBox.Show("Введите id марки");
                    return;
                }
                if (string.IsNullOrWhiteSpace(dpStartDate2.Text))
                {
                    MessageBox.Show("Введите дату начала действия договора");
                    return;
                }
                if (string.IsNullOrWhiteSpace(dpEndDate2.Text))
                {
                    MessageBox.Show("Введите дату конца действия договора");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtTerms.Text))
                {
                    MessageBox.Show("Введите основание договора");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtManufacturerID.Text) || string.IsNullOrWhiteSpace(dpStartDate2.Text) || string.IsNullOrWhiteSpace(dpEndDate2.Text) || string.IsNullOrWhiteSpace(txtTerms.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtManufacturerID.Text))
                {
                    MessageBox.Show("ID компании должен содержать только цифры.");
                    return;
                }

                var newManufacturerContract = new ManufacturerContracts
                {
                    ManufacturerID = int.Parse(txtManufacturerID.Text),
                    StartDate = dpStartDate2.SelectedDate.Value,
                    EndDate = dpEndDate2.SelectedDate.Value,
                    Terms = txtTerms.Text
                };

                entities.ManufacturerContracts.Add(newManufacturerContract);
                entities.SaveChanges();
                gridManufacturerContracts.ItemsSource = entities.ManufacturerContracts.ToList();
                MessageBox.Show("Контракт с производителем успешно добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditManufacturerContract_Click(object sender, RoutedEventArgs e)
        {
            if (gridManufacturerContracts.SelectedItem != null)
            {
                var selectedManufacturerContract = gridManufacturerContracts.SelectedItem as ManufacturerContracts;
                selectedManufacturerContract.ManufacturerID = int.Parse(txtManufacturerID.Text);
                selectedManufacturerContract.StartDate = dpStartDate2.SelectedDate.Value;
                selectedManufacturerContract.EndDate = dpEndDate2.SelectedDate.Value;
                selectedManufacturerContract.Terms = txtTerms.Text;

                entities.SaveChanges();
                gridManufacturerContracts.Items.Refresh();
                MessageBox.Show("Контракт с производителем успешно изменен.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите контракт с производителем для изменения.");
            }
        }

        private void DeleteManufacturerContract_Click(object sender, RoutedEventArgs e)
        {
            if (gridManufacturerContracts.SelectedItem != null)
            {
                var selectedManufacturerContract = gridManufacturerContracts.SelectedItem as ManufacturerContracts;
                entities.ManufacturerContracts.Remove(selectedManufacturerContract);
                entities.SaveChanges();
                gridManufacturerContracts.ItemsSource = entities.ManufacturerContracts.ToList();
                MessageBox.Show("Контракт с производителем успешно удален.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите контракт с производителем для удаления.");
            }
        }


        private void AddLoan_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCustomerID3.Text))
                {
                    MessageBox.Show("Введите id клиента");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtLoanAmount.Text))
                {
                    MessageBox.Show("Введите сумму кредита");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtInterestRate.Text))
                {
                    MessageBox.Show("Введите процентную ставку");
                    return;
                }
                if (string.IsNullOrWhiteSpace(Duration.Text))
                {
                    MessageBox.Show("Введите срок кредита");
                    return;
                }
                if (string.IsNullOrWhiteSpace(BankName.Text))
                {
                    MessageBox.Show("Введите имя банка");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtCustomerID3.Text) || string.IsNullOrWhiteSpace(txtLoanAmount.Text) || string.IsNullOrWhiteSpace(txtInterestRate.Text) || string.IsNullOrWhiteSpace(Duration.Text) || string.IsNullOrWhiteSpace(BankName.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(BankName.Text))
                {
                    MessageBox.Show("ID клиента должен содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtLoanAmount.Text))
                {
                    MessageBox.Show("Цена должна содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(txtInterestRate.Text))
                {
                    MessageBox.Show("Процентная ставка должна содержать только цифры.");
                    return;
                }
                if (!IsPhoneNumber(Duration.Text))
                {
                    MessageBox.Show("Срок кредитования должен содержать только цифры.");
                    return;
                }

                var newLoan = new Loans
                {
                    CustomerID = int.Parse(txtCustomerID3.Text),
                    Amount = decimal.Parse(txtLoanAmount.Text),
                    InterestRate = decimal.Parse(txtInterestRate.Text),
                    Duration = int.Parse(Duration.Text),
                    BankName = BankName.Text
                   
                };

                entities.Loans.Add(newLoan);
                entities.SaveChanges();
                gridLoans.ItemsSource = entities.Loans.ToList();
                MessageBox.Show("Запись о займе успешно добавлена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

     
        private void EditLoan_Click(object sender, RoutedEventArgs e)
        {
            if (gridLoans.SelectedItem != null)
            {
                var selectedLoan = gridLoans.SelectedItem as Loans;
                selectedLoan.CustomerID = int.Parse(txtCustomerID3.Text);
                selectedLoan.Amount = decimal.Parse(txtLoanAmount.Text);
                selectedLoan.InterestRate = decimal.Parse(txtInterestRate.Text);
                selectedLoan.Duration = int.Parse(Duration.Text);
                selectedLoan.BankName = BankName.Text;
           

                entities.SaveChanges();
                gridLoans.Items.Refresh();
                MessageBox.Show("Запись о займе успешно изменена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запись о займе для изменения.");
            }
        }

   
        private void DeleteLoan_Click(object sender, RoutedEventArgs e)
        {
            if (gridLoans.SelectedItem != null)
            {
                var selectedLoan = gridLoans.SelectedItem as Loans;
                entities.Loans.Remove(selectedLoan);
                entities.SaveChanges();
                gridLoans.ItemsSource = entities.Loans.ToList();
                MessageBox.Show("Запись о займе успешно удалена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запись о займе для удаления.");
            }
        }



        private void AddInsurance_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCustomerID2.Text))
                {
                    MessageBox.Show("Введите id клиента");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtInsuranceType.Text))
                {
                    MessageBox.Show("Введите id авто");
                    return;
                }
                if (string.IsNullOrWhiteSpace(dpStartDate.Text))
                {
                    MessageBox.Show("Введите номер полиса");
                    return;
                }
                if (string.IsNullOrWhiteSpace(dpEndDate.Text))
                {
                    MessageBox.Show("Введите дату истечения срока действия полиса");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPremium.Text))
                {
                    MessageBox.Show("Введите тип полиса");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtCustomerID2.Text) || string.IsNullOrWhiteSpace(txtInsuranceType.Text) || string.IsNullOrWhiteSpace(dpStartDate.Text) || string.IsNullOrWhiteSpace(dpEndDate.Text) || string.IsNullOrWhiteSpace(txtPremium.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                    return;
                }

                if (!IsPhoneNumber(txtCustomerID2.Text))
                {
                    MessageBox.Show("ID клиента должен содержать только цифры.");
                }
                if (!IsPhoneNumber(txtInsuranceType.Text))
                {
                    MessageBox.Show("ID авто должен содержать только цифры.");
                }
                if (!IsPhoneNumber(dpStartDate.Text))
                {
                    MessageBox.Show("Страховой полис должен содержать только цифры.");
                }


                var newInsurance = new Insurances
                {
                    CustomerID = int.Parse(txtCustomerID2.Text),
                    CarID = int.Parse(txtInsuranceType.Text),
                    PolicyNumber = dpStartDate.Text,
                    ExpiryDate = dpEndDate.SelectedDate.Value,
                    Type = txtPremium.Text
                };

                entities.Insurances.Add(newInsurance);
                entities.SaveChanges();
                gridInsurances.ItemsSource = entities.Insurances.ToList();
                MessageBox.Show("Страховой полис успешно добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditInsurance_Click(object sender, RoutedEventArgs e)
        {
            if (gridInsurances.SelectedItem != null)
            {
                var selectedInsurance = gridInsurances.SelectedItem as Insurances;
                selectedInsurance.CustomerID = int.Parse(txtCustomerID2.Text);
                selectedInsurance.CarID = int.Parse(txtInsuranceType.Text);
                selectedInsurance.PolicyNumber = dpStartDate.Text;
                selectedInsurance.ExpiryDate = dpEndDate.SelectedDate.Value;
                selectedInsurance.Type = txtPremium.Text;

                entities.SaveChanges();
                gridInsurances.Items.Refresh();
                MessageBox.Show("Страховой полис успешно изменен.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите страховой полис для изменения.");
            }
        }

        private void DeleteInsurance_Click(object sender, RoutedEventArgs e)
        {
            if (gridInsurances.SelectedItem != null)
            {
                var selectedInsurance = gridInsurances.SelectedItem as Insurances;
                entities.Insurances.Remove(selectedInsurance);
                entities.SaveChanges();
                gridInsurances.ItemsSource = entities.Insurances.ToList();
                MessageBox.Show("Страховой полис успешно удален.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите страховой полис для удаления.");
            }
        }


        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            TabItem selectedTab = (sender as TabControl)?.SelectedItem as TabItem;
            switch (selectedTab?.Header)
            {
                case "Customers":
                    gridCustomers.ItemsSource = entities.Customers.ToList();
                    break;
                case "Cars":
                    gridCars.ItemsSource = entities.Cars.ToList();
                    break;
                case "Sales":
                    gridSales.ItemsSource = entities.Sales.ToList();
                    break;
                case "Employees":
                    gridEmployees.ItemsSource = entities.Employees.ToList();
                    break;
                case "Manufacturers":
                    gridManufacturers.ItemsSource = entities.Manufacturers.ToList();
                    break;
                case "Services":
                    gridServices.ItemsSource = entities.Services.ToList();
                    break;
                case "Parts":
                    gridParts.ItemsSource = entities.Parts.ToList();
                    break;
                case "Suppliers":
                    gridSuppliers.ItemsSource = entities.Suppliers.ToList();
                    break;
                case "PartSuppliers":
                    gridPartSuppliers.ItemsSource = entities.PartSuppliers.ToList();
                    break;
                case "Warehouse":
                    gridWarehouse.ItemsSource = entities.Warehouse.ToList();
                    break;
                case "Complaints":
                    gridComplaints.ItemsSource = entities.Complaints.ToList();
                    break;
                case "Insurances":
                    gridInsurances.ItemsSource = entities.Insurances.ToList();
                    break;
                case "Loans":
                    gridLoans.ItemsSource = entities.Loans.ToList();
                    break;
                case "ManufacturerContracts":
                    gridManufacturerContracts.ItemsSource = entities.ManufacturerContracts.ToList();
                    break;
            }
        }

        private void BackupButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //дату и тик так  
                string backupName = $"Backup_{DateTime.Now.ToString("yyyyMMdd_HHmmss")}.bak";

                //выбор места по жизни
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.FileName = backupName;
                saveFileDialog.Filter = "Backup Files (*.bak)|*.bak";

                if (saveFileDialog.ShowDialog() == true)
                {
                    // получаем выбранный путь по жизни
                    string backupPath = saveFileDialog.FileName;

                    // подключаемся к бд
                    using (SqlConnection connection = new SqlConnection("Server=Kobra\\SQLEXPRESS;Database=storeAuto;Integrated Security=True;"))
                    {
                        connection.Open();

                        // бэкапаем
                        using (SqlCommand command = new SqlCommand($"BACKUP DATABASE storeAuto TO DISK = '{backupPath}'", connection))
                        {
                            command.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Бэкап базы данных успешно создан.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании бэкапа базы данных: {ex.Message}");
            }
        }


        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid dataGrid = (DataGrid)sender;

            if (dataGrid.SelectedItem != null)
            {
                dynamic selectedItem = dataGrid.SelectedItem;
                switch (dataGrid.Name)
                {
                    case "gridCustomers":
                        txtCustomerName.Text = selectedItem.Name;
                        txtPhone.Text = selectedItem.Phone;
                        txtEmail.Text = selectedItem.Email;
                        txtAddress.Text = selectedItem.Address;
                        break;
                    case "gridCars":
                        txtMake.Text = selectedItem.Make;
                        txtModel.Text = selectedItem.Model;
                        txtYear.Text = selectedItem.Year.ToString();
                        txtPrice.Text = selectedItem.Price.ToString();
                        txtColor.Text = selectedItem.Color;
                        break;
                    case "gridSales":
                        txtCustomerID.Text = selectedItem.CustomerID.ToString();
                        txtCarID.Text = selectedItem.CarID.ToString();
                        dpSaleDate.SelectedDate = selectedItem.SaleDate;
                        txtSalePrice.Text = selectedItem.SalePrice.ToString();
                        txtNote.Text = selectedItem.Note;
                        break;
                    case "gridEmployees":
                        txtEmployeeName.Text = selectedItem.Name;
                        txtPosition.Text = selectedItem.Position;
                        txtSalary.Text = selectedItem.Salary.ToString();
                        dpHireDate.SelectedDate = selectedItem.HireDate;
                        txtDepartment.Text = selectedItem.Department.ToString();
                        txtLogin.Text = selectedItem.Login.ToString();
                        txtPassword.Text = selectedItem.Password.ToString();
                        break;
                    case "gridManufacturers":
                        txtManufacturerName.Text = selectedItem.Name;
                        txtCountry.Text = selectedItem.Country;
                        txtWebsite.Text = selectedItem.Website;
                        break;
                    case "gridServices":
                        txtCarID1.Text = selectedItem.CarID.ToString();
                        dpServiceDate.SelectedDate = selectedItem.ServiceDate;
                        txtDescription.Text = selectedItem.Description;
                        txtCost.Text = selectedItem.Cost.ToString();
                        txtStatus.Text = selectedItem.Status;
                        break;
                    case "gridParts":
                        txtPartName.Text = selectedItem.Name;
                        txtPartDescription.Text = selectedItem.Description;
                        txtPartPrice.Text = selectedItem.Price.ToString();
                        txtPartCategory.Text = selectedItem.Category;
                        break;
                    case "gridSuppliers":
                        txtSupplierName.Text = selectedItem.Name;
                        txtContactName.Text = selectedItem.ContactName;
                        txtSupplierPhone.Text = selectedItem.Phone;
                        txtSupplierAddress.Text = selectedItem.Address;
                        txtSupplierEmail.Text = selectedItem.Email;
                        break;
                    case "gridPartSuppliers":
                        txtPartID.Text = selectedItem.PartID.ToString();
                        txtSupplierID.Text = selectedItem.SupplierID.ToString();
                        txtPartSupplierPrice.Text = selectedItem.Price.ToString();
                        txtDeliveryStatus.Text = selectedItem.DeliveryStatus;
                        break;
                    case "gridWarehouse":
                        txtWarehousePartID.Text = selectedItem.PartID.ToString();
                        txtQuantity.Text = selectedItem.Quantity.ToString();
                        txtLocation.Text = selectedItem.Location;
                        break;
                    case "gridComplaints":
                        txtCustomerID1.Text = selectedItem.CustomerID.ToString();
                        txtComplaintDescription.Text = selectedItem.Description;
                        txtResolution.Text = selectedItem.Resolution;
                        txtComplaintStatus.Text = selectedItem.Status;
                        break;
                    case "gridInsurances":
                        txtCustomerID2.Text = selectedItem.CustomerID.ToString();
                        txtInsuranceType.Text = selectedItem.CarID.ToString();
                        dpStartDate.Text = selectedItem.PolicyNumber;
                        dpEndDate.SelectedDate = selectedItem.ExpiryDate;
                        txtPremium.Text = selectedItem.Type;
                        break;

                    case "gridLoans":
                        txtCustomerID3.Text = selectedItem.CustomerID.ToString();
                        txtLoanAmount.Text = selectedItem.Amount.ToString();
                        Duration.Text = selectedItem.Duration.ToString();
                        BankName.Text = selectedItem.BankName;
                        txtInterestRate.Text = selectedItem.InterestRate.ToString();
                        break;


                    case "gridManufacturerContracts":
                        txtManufacturerID.Text = selectedItem.ManufacturerID.ToString();
                        dpStartDate2.SelectedDate = selectedItem.StartDate;
                        dpEndDate2.SelectedDate = selectedItem.EndDate;
                        txtTerms.Text = selectedItem.Terms;
                        break;
                }

            }
        }

        private void gridCustomers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}